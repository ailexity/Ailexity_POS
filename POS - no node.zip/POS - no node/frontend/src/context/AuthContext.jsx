import React, { createContext, useState, useEffect, useContext } from 'react';
import api from '../api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    const fetchUser = async () => {
        const token = localStorage.getItem('token');
        if (token) {
            try {
                const response = await api.get('/users/me');
                setUser(response.data);
            } catch (error) {
                console.error("Failed to fetch user", error);
                localStorage.removeItem('token');
                setUser(null);
            }
        }
        setLoading(false);
    };

    useEffect(() => {
        fetchUser();
    }, []);

    const login = async (username, password) => {
        const formData = new URLSearchParams();
        formData.append('username', username);
        formData.append('password', password);

        try {
            // Backend OAuth2 expects application/x-www-form-urlencoded
            const response = await api.post('/token', formData, {
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            });
            localStorage.setItem('token', response.data.access_token);
            await fetchUser();
            return { success: true };
        } catch (error) {
            console.error("Login failed detailed:", error);
            if (error.response) {
                // Server replied with an error (401, 403, etc.)
                const msg = error.response.data?.detail || "Invalid username or password.";
                return { success: false, error: typeof msg === "string" ? msg : msg.join?.(" ") || "Invalid credentials." };
            }
            // No response = backend not reachable (ERR_CONNECTION_REFUSED, etc.)
            if (error.code === "ERR_NETWORK" || !error.response) {
                return { success: false, error: "Cannot reach server. Start the backend (run start_backend.bat or start_all.bat)." };
            }
            return { success: false, error: "Login failed. Please try again." };
        }
    };

    const logout = () => {
        localStorage.removeItem('token');
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, login, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
