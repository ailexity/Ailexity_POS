import React, { createContext, useState, useContext, useMemo, useEffect } from 'react';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
    // Initialize selected table from localStorage
    const [selectedTable, setSelectedTable] = useState(() => {
        try {
            const savedTable = localStorage.getItem('selectedTable');
            return savedTable ? JSON.parse(savedTable) : null;
        } catch (error) {
            console.error('Error loading selected table from localStorage:', error);
            return null;
        }
    });

    // Initialize table carts from localStorage (separate cart for each table)
    const [tableCarts, setTableCarts] = useState(() => {
        try {
            const savedTableCarts = localStorage.getItem('tableCarts');
            return savedTableCarts ? JSON.parse(savedTableCarts) : {};
        } catch (error) {
            console.error('Error loading table carts from localStorage:', error);
            return {};
        }
    });

    // Initialize tax rate from localStorage
    const [taxRate, setTaxRate] = useState(() => {
        try {
            const savedTaxRate = localStorage.getItem('taxRate');
            return savedTaxRate ? parseFloat(savedTaxRate) : 0;
        } catch (error) {
            console.error('Error loading tax rate from localStorage:', error);
            return 0;
        }
    });

    // Get current table's cart items
    const cartItems = useMemo(() => {
        if (!selectedTable) return [];
        return tableCarts[selectedTable.id] || [];
    }, [selectedTable, tableCarts]);

    // Persist selected table to localStorage
    useEffect(() => {
        try {
            if (selectedTable) {
                localStorage.setItem('selectedTable', JSON.stringify(selectedTable));
            } else {
                localStorage.removeItem('selectedTable');
            }
        } catch (error) {
            console.error('Error saving selected table to localStorage:', error);
        }
    }, [selectedTable]);

    // Persist table carts to localStorage
    useEffect(() => {
        try {
            localStorage.setItem('tableCarts', JSON.stringify(tableCarts));
        } catch (error) {
            console.error('Error saving table carts to localStorage:', error);
        }
    }, [tableCarts]);

    // Persist tax rate to localStorage whenever it changes
    useEffect(() => {
        try {
            localStorage.setItem('taxRate', taxRate.toString());
        } catch (error) {
            console.error('Error saving tax rate to localStorage:', error);
        }
    }, [taxRate]);

    const selectTable = (table) => {
        setSelectedTable(table);
    };

    const addToCart = (item) => {
        if (!selectedTable) {
            alert('Please select a table first');
            return;
        }
        
        setTableCarts(prev => {
            const tableCart = prev[selectedTable.id] || [];
            const existing = tableCart.find(i => i.id === item.id);
            
            const newTableCart = existing
                ? tableCart.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i)
                : [...tableCart, { ...item, qty: 1 }];
            
            return {
                ...prev,
                [selectedTable.id]: newTableCart
            };
        });
    };

    const removeFromCart = (itemId) => {
        if (!selectedTable) return;
        
        setTableCarts(prev => ({
            ...prev,
            [selectedTable.id]: (prev[selectedTable.id] || []).filter(i => i.id !== itemId)
        }));
    };

    const updateQty = (itemId, qty) => {
        if (!selectedTable) return;
        
        if (qty <= 0) {
            removeFromCart(itemId);
            return;
        }
        
        setTableCarts(prev => ({
            ...prev,
            [selectedTable.id]: (prev[selectedTable.id] || []).map(i => 
                i.id === itemId ? { ...i, qty } : i
            )
        }));
    };

    const clearCart = () => {
        if (!selectedTable) return;
        
        setTableCarts(prev => ({
            ...prev,
            [selectedTable.id]: []
        }));
    };

    const clearTableCart = (tableId) => {
        setTableCarts(prev => {
            const newCarts = { ...prev };
            delete newCarts[tableId];
            return newCarts;
        });
    };

    const setUserTaxRate = (rate) => setTaxRate(rate || 0);

    const cartTotal = useMemo(() => {
        return cartItems.reduce((acc, item) => acc + (item.price * item.qty), 0);
    }, [cartItems]);

    const cartTax = useMemo(() => {
        // Use global tax rate for all items
        return cartItems.reduce((acc, item) => acc + (item.price * item.qty * (taxRate / 100)), 0);
    }, [cartItems, taxRate]);

    const grandTotal = useMemo(() => {
        return cartTotal + cartTax;
    }, [cartTotal, cartTax]);

    return (
        <CartContext.Provider value={{
            selectedTable,
            selectTable,
            cartItems,
            taxRate,
            addToCart,
            removeFromCart,
            updateQty,
            clearCart,
            clearTableCart,
            setUserTaxRate,
            cartTotal,
            cartTax,
            grandTotal,
            tableCarts
        }}>
            {children}
        </CartContext.Provider>
    );
};

export const useCart = () => useContext(CartContext);
