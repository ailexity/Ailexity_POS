import React, { useEffect, useState } from 'react';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { Search, Plus, Minus, Trash2, ShoppingCart, Grid, Package, Smartphone, FileText, Grid3x3 } from 'lucide-react';

const POS = () => {
    const [items, setItems] = useState([]);
    const [search, setSearch] = useState("");
    const { selectedTable, selectTable, cartItems, addToCart, removeFromCart, updateQty, cartTotal, cartTax, grandTotal, clearCart, setUserTaxRate, tableCarts } = useCart();
    const { user } = useAuth();
    const [loading, setLoading] = useState(false);
    const [activeCategory, setActiveCategory] = useState("All");
    const [customerName, setCustomerName] = useState("");
    const [customerPhone, setCustomerPhone] = useState("");
    const [lastInvoice, setLastInvoice] = useState(null);
    const [tables, setTables] = useState([]);
    const [showTableSelector, setShowTableSelector] = useState(false);

    // Set tax rate when user loads
    useEffect(() => {
        if (user && setUserTaxRate) {
            setUserTaxRate(user.tax_rate || 0);
        }
    }, [user, setUserTaxRate]);

    useEffect(() => {
        const fetchItems = async () => {
            try {
                const res = await api.get('/items/');
                setItems(res.data);
            } catch (e) {
                console.error(e);
            }
        };
        fetchItems();
    }, []);

    useEffect(() => {
        const fetchTables = async () => {
            try {
                const res = await api.get('/tables');
                setTables(res.data.filter(t => t.is_active));
            } catch (e) {
                console.error('Error fetching tables:', e);
            }
        };
        fetchTables();
    }, []);

    // Get unique categories (case-insensitive grouping, but keep original case for display)
    const categoryMap = new Map();
    items.forEach(item => {
        if (item.category) {
            const lowerKey = item.category.toLowerCase();
            if (!categoryMap.has(lowerKey)) {
                categoryMap.set(lowerKey, item.category);
            }
        }
    });
    const categories = ["All", ...categoryMap.values()];

    const filteredItems = items.filter(i =>
        (activeCategory === "All" || i.category?.toLowerCase() === activeCategory.toLowerCase()) &&
        i.name.toLowerCase().includes(search.toLowerCase())
    );

    const handleCheckout = async () => {
        if (!cartItems?.length) {
            alert("Please add items to cart before completing order");
            return;
        }

        setLoading(true);
        try {
            const taxRate = user?.tax_rate ?? 0;
            // Get current local date and time
            const now = new Date();
            // Create local datetime string (YYYY-MM-DDTHH:mm:ss format without timezone)
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const localDateTime = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
            
            const payload = {
                customer_name: customerName || "Walk-in Customer",
                customer_phone: customerPhone || "",
                payment_mode: "Cash",
                table_number: selectedTable?.table_number || null,
                table_name: selectedTable?.table_name || null,
                created_at: localDateTime, // Send local datetime without timezone conversion
                items: cartItems.map((i) => ({
                    item_id: i.id != null ? String(i.id) : null,
                    item_name: String(i.name || ""),
                    quantity: Math.max(1, Math.floor(Number(i.qty) || 1)),
                    unit_price: Number(i.price) || 0,
                    tax_amount: (Number(i.price) || 0) * (Math.floor(Number(i.qty) || 1)) * (taxRate / 100),
                })),
            };

            const res = await api.post("/invoices/", payload);
            setLastInvoice(res.data);
            clearCart();
            setCustomerName("");
            setCustomerPhone("");

            if (customerPhone) {
                const sendWhatsApp = window.confirm(
                    `Invoice Created: ${res.data.invoice_number}${selectedTable ? `\nTable: ${selectedTable.table_name}` : ''}\n\nWould you like to send this invoice via WhatsApp?`
                );
                if (sendWhatsApp) {
                    shareWhatsApp(res.data);
                }
            } else {
                alert(`Invoice Created: ${res.data.invoice_number}${selectedTable ? `\nTable: ${selectedTable.table_name}` : ''}`);
            }
        } catch (e) {
            console.error("Checkout error:", e);
            let errorMessage = "Unknown error occurred";
            if (e.response?.data?.detail != null) {
                const d = e.response.data.detail;
                if (typeof d === "string") {
                    errorMessage = d;
                } else if (Array.isArray(d)) {
                    errorMessage = d.map((x) => (x.msg != null ? x.msg : String(x))).join("; ");
                } else {
                    errorMessage = String(d);
                }
            } else if (e.message) {
                errorMessage = e.message;
            }
            if (e.code === "ERR_NETWORK" || (!e.response && e.message)) {
                errorMessage = "Cannot reach server. Make sure the backend is running (start_backend.bat or start_all.bat).";
            }
            alert(`Checkout Failed: ${errorMessage}`);
        } finally {
            setLoading(false);
        }
    };

    const shareWhatsApp = async (invoice) => {
        // Get customer name for personalization
        const custName = invoice.customer_name || customerName || 'Valued Customer';
        const businessName = invoice.business_name || user?.business_name || 'Our Store';

        // Generate invoice URL
        const invoiceUrl = `${window.location.origin}/invoice/${invoice.id}`;

        // Load WhatsApp template from localStorage
        let template = {
            greeting: 'Dear {customer_name},',
            thank_you: 'Thank you for your recent order at {business_name}!\nYour invoice is now available. 🪄',
            closing: 'Loved your experience? Or something to improve? Tap to tell us! 🌟',
            show_invoice_link: true,
            show_date: true,
            show_total: true
        };
        
        try {
            const savedTemplate = localStorage.getItem('whatsapp_template');
            if (savedTemplate) {
                template = { ...template, ...JSON.parse(savedTemplate) };
            }
        } catch (e) {
            console.error('Error loading WhatsApp template:', e);
        }

        // Build the message using template
        let message = template.greeting.replace('{customer_name}', custName);
        message += '\n\n' + template.thank_you.replace('{business_name}', businessName);
        message += '\n';
        
        if (template.show_total) {
            message += `\n💰 Amount : Rs.${invoice.total_amount.toFixed(0)}`;
        }
        
        if (template.show_date) {
            const date = new Date(invoice.created_at);
            const dateStr = date.toLocaleDateString('en-IN', { 
                day: '2-digit',
                month: '2-digit', 
                year: 'numeric',
                timeZone: 'Asia/Kolkata' 
            }).replace(/\//g, '/');
            const timeStr = date.toLocaleTimeString('en-IN', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false,
                timeZone: 'Asia/Kolkata'
            });
            message += `\n📅 Date : ${dateStr} ${timeStr}`;
        }
        
        if (template.show_invoice_link) {
            message += `\n👁 View Invoice : ${invoiceUrl}`;
        }
        
        message += '\n\n' + template.closing;

        const phone = invoice.customer_phone || customerPhone;
        const url = `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
        window.open(url, '_blank');
    };


    return (
        <div className="pos-container">
            {/* LEFT: Item Selection Area */}
            <div className="pos-left-panel" style={{ position: 'relative' }}>
                {/* Header with Table Selector */}
                <div className="header-section">
                    <div className="flex items-center justify-between w-full">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 flex items-center justify-center bg-indigo-600 shadow-sm">
                                <Grid color="white" size={18} />
                            </div>
                            <div className="page-title">
                                <h1>Billing</h1>
                                <p className="text-xs text-muted mt-1">Select items below</p>
                            </div>
                        </div>
                        
                        {/* Table Selector Button */}
                        <button
                            onClick={() => setShowTableSelector(!showTableSelector)}
                            className={"btn flex items-center gap-2"}
                        >
                            <Grid3x3 size={18} />
                            <span className="font-medium">
                                {selectedTable ? selectedTable.table_name : 'Select Table'}
                            </span>
                        </button>
                    </div>
                </div>

                {/* Table Selector Dropdown - Outside header */}
                {showTableSelector && (
                    <div 
                        className="absolute bg-white border border-gray-200 rounded-lg shadow-lg z-50 w-96 max-h-64"
                        style={{ 
                            right: '16px',
                            top: 'px'
                        }}
                    >
                        <div className="p-a border-b bg-gray-50">
                            <h3 className="font-semibold text-gray-800">Select a Table</h3>
                        </div>
                        <div className="p-3">
                            {tables.length === 0 ? (
                                <div className="text-center py-6 text-gray-500">
                                    <p className="text-sm">No tables configured</p>
                                    <p className="text-xs mt-1">Go to Settings to add tables</p>
                                </div>
                            ) : (
                                <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: 'thin' }}>
                                    {tables.map(table => {
                                        const hasOrders = tableCarts[table.id] && tableCarts[table.id].length > 0;
                                        return (
                                            <button
                                                key={table.id}
                                                onClick={() => {
                                                    selectTable(table);
                                                    setShowTableSelector(false);
                                                }}
                                                className={`flex-shrink-0 p-4 rounded-lg border-2 text-center transition-all min-w-[120px] relative ${
                                                    selectedTable?.id === table.id
                                                        ? 'border-green-500 bg-green-50'
                                                        : 'border-gray-200 hover:border-indigo-400 hover:bg-indigo-50'
                                                }`}
                                            >
                                                {hasOrders && (
                                                    <div className="absolute top-2 right-2 w-3 h-3 bg-orange-500 rounded-full border-2 border-white shadow-sm" title="Has ongoing orders"></div>
                                                )}
                                                <div className="font-bold text-lg mb-1">{table.table_name}</div>
                                                <div className="text-xs text-gray-600">#{table.table_number}</div>
                                                <div className="text-xs text-gray-500 mt-1">{table.capacity} seats</div>
                                                {hasOrders && (
                                                    <div className="text-zh text-blue-600 font-semibold mt-1">
                                                        Occupied
                                                    </div>
                                                )}
                                            </button>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Categories with Search Bar */}
                <div className="category-bar" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', flex: '1' }}>
                        {categories.map(cat => (
                            <button
                                key={cat}
                                onClick={() => setActiveCategory(cat)}
                                className={`category-tab ${activeCategory.toLowerCase() === cat.toLowerCase() ? 'active' : ''}`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                    
                    {/* Search Bar */}
                    <div className="pos-search-wrapper" style={{ width: '280px', margin: 0 }}>
                        <Search className="pos-search-icon" size={18} />
                        <input
                            className="pos-search-input-field"
                            placeholder="Search items..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                </div>

                {/* Item Grid */}
                <div className="pos-grid-area custom-scrollbar">
                    <div className="pos-grid">
                        {filteredItems.map(item => (
                            <div
                                key={item.id}
                                className="pos-item-card"
                                onClick={() => addToCart(item)}
                            >
                                <div className="flex justify-between items-start mb-2">
                                    <div style={{ width: '28px', height: '28px', background: '#eff6ff', color: '#4f46e5', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '0.875rem' }}>
                                        {item.name.charAt(0)}
                                    </div>
                                    <span className="price-badge" style={{ fontSize: '0.75rem', padding: '0.15rem 0.4rem' }}>
                                        ₹{item.price}
                                    </span>
                                </div>

                                <h3 style={{ marginBottom: '0.125rem', fontSize: '0.875rem' }}>{item.name}</h3>
                                <p className="text-xs text-muted" style={{ textTransform: 'uppercase', letterSpacing: '0.05em', fontSize: '0.625rem' }}>{item.category}</p>

                                <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-100" style={{ borderTop: '1px solid #f1f5f9' }}>
                                    <span className={`text-xs ${item.stock_quantity < 10 ? "text-danger" : "text-success"}`} style={{ fontWeight: 500, fontSize: '0.625rem' }}>
                                        {item.stock_quantity} in stock
                                    </span>
                                    <div style={{ padding: '0.25rem', background: '#f8fafc', color: '#64748b', display: 'flex' }}>
                                        <Plus size={12} />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* RIGHT: Cart Panel */}
            <div className="pos-cart-panel" style={{ width: '35%' }}>
                {/* Cart Header */}
                <div className="cart-header">
                    <div className="flex items-center gap-2">
                        <ShoppingCart size={20} className="text-muted" />
                        <h2>Current Order</h2>
                    </div>
                    <div className="text-xs text-muted font-mono">
                        #TRX-{Math.floor(Math.random() * 1000)}
                    </div>
                </div>

                {/* Cart Items */}
                <div className="cart-list custom-scrollbar">
                    {cartItems.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-muted">
                            <Package size={48} style={{ opacity: 0.4, marginBottom: '1rem' }} />
                            <p className="text-sm">No items yet</p>
                        </div>
                    ) : (
                        cartItems.map(item => (
                            <div key={item.id} className="cart-item">
                                <div className="flex justify-between items-center">
                                    <div className="flex-1 flex flex-col justify-center">
                                        <h4 style={{ fontSize: '0.875rem', fontWeight: 600, color: '#1e293b', marginBottom: '0.125rem' }}>{item.name}</h4>
                                        <div className="text-xs text-muted">₹{item.price} × {item.qty}</div>
                                    </div>

                                    <div className="flex items-center gap-2">
                                        <div className="flex items-center" style={{ border: '1px solid #e2e8f0', background: 'white' }}>
                                            <button
                                                className="btn-icon"
                                                style={{ padding: '0.25rem' }}
                                                onClick={(e) => { e.stopPropagation(); updateQty(item.id, item.qty - 1); }}
                                            >
                                                <Minus size={12} />
                                            </button>
                                            <span style={{ width: '32px', textAlign: 'center', fontSize: '0.75rem', fontWeight: 700 }}>{item.qty}</span>
                                            <button
                                                className="btn-icon"
                                                style={{ padding: '0.25rem' }}
                                                onClick={(e) => { e.stopPropagation(); updateQty(item.id, item.qty + 1); }}
                                            >
                                                <Plus size={12} />
                                            </button>
                                        </div>

                                        <span style={{ fontSize: '0.875rem', fontWeight: 700, color: '#1e293b', minWidth: '60px', textAlign: 'right' }}>₹{(item.price * item.qty).toFixed(2)}</span>

                                        <button
                                            className="btn-icon danger"
                                            style={{ padding: '0.25rem' }}
                                            onClick={(e) => { e.stopPropagation(); removeFromCart(item.id); }}
                                        >
                                            <Trash2 size={14} />
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* Cart Footer */}
                <div className="cart-footer">
                    {/* Customer Info Section */}
                    {cartItems.length > 0 && (
                        <div className="mb-4 pb-4 border-b" style={{ borderBottom: '1px solid var(--border-color)' }}>
                            <h3 className="text-sm font-bold mb-3 text-main">Customer Details (Optional)</h3>
                            <div className="flex flex-col gap-2">
                                <input
                                    className="input"
                                    type="text"
                                    placeholder="Customer Name"
                                    value={customerName}
                                    onChange={(e) => setCustomerName(e.target.value)}
                                    style={{ fontSize: '0.875rem', padding: '0.5rem 0.75rem' }}
                                />
                                <input
                                    className="input"
                                    type="tel"
                                    placeholder="Phone Number (for WhatsApp)"
                                    value={customerPhone}
                                    onChange={(e) => setCustomerPhone(e.target.value)}
                                    style={{ fontSize: '0.875rem', padding: '0.5rem 0.75rem' }}
                                />
                            </div>
                            {customerPhone && (
                                <p className="text-xs text-muted mt-2" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                                    <span style={{ color: '#10b981' }}>✓</span> Invoice will be sent via WhatsApp
                                </p>
                            )}
                        </div>
                    )}

                    <div className="mb-3">
                        <div className="summary-row">
                            <span>Subtotal</span>
                            <span>₹{cartTotal.toFixed(2)}</span>
                        </div>
                        <div className="summary-row">
                            <span>Tax ({user?.tax_rate || 0}%)</span>
                            <span>₹{cartTax.toFixed(2)}</span>
                        </div>
                        <div className="total-row">
                            <span>Total</span>
                            <span>₹{(cartTotal + cartTax).toFixed(2)}</span>
                        </div>
                    </div>

                    {/* Success Message with WhatsApp Button */}
                    {lastInvoice && (
                        <div className="mb-4 p-4 border" style={{ background: '#f0fdf4', borderColor: '#86efac' }}>
                            <div className="flex items-center gap-2 mb-2">
                                <span style={{ color: '#16a34a', fontSize: '1.25rem' }}>✓</span>
                                <h3 className="text-sm font-bold" style={{ color: '#16a34a' }}>Order Completed!</h3>
                            </div>
                            <p className="text-xs mb-3" style={{ color: '#15803d' }}>
                                Invoice #{lastInvoice.invoice_number} created successfully
                            </p>
                            {lastInvoice.customer_phone && (
                                <button
                                    className="btn w-full"
                                    onClick={() => shareWhatsApp(lastInvoice)}
                                    style={{ background: '#25D366', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}
                                >
                                    <Smartphone size={16} />
                                    Send Invoice via WhatsApp
                                </button>
                            )}
                            {!lastInvoice.customer_phone && (
                                <p className="text-xs text-center text-muted">
                                    Add phone number to send via WhatsApp
                                </p>
                            )}
                            <button
                                className="text-xs text-muted mt-2 w-full text-center"
                                onClick={() => setLastInvoice(null)}
                                style={{ background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline' }}
                            >
                                Start New Order
                            </button>
                        </div>
                    )}

                    {/* Complete Order Button */}
                    <button
                        type="button"
                        className="btn w-full"
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            handleCheckout();
                        }}
                        disabled={!!(loading || !cartItems?.length)}
                        aria-label="Complete order and create invoice"
                    >
                        {loading ? "Processing…" : "COMPLETE ORDER"}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default POS;
