import React, { useState, useEffect } from 'react';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { Settings as SettingsIcon, Save, Eye, EyeOff, Building, Lock, Grid3x3, Plus, Edit2, Trash2, FileText, CreditCard, Keyboard } from 'lucide-react';

const Settings = () => {
    const { user: currentUser } = useAuth();
    const [activeTab, setActiveTab] = useState('business');
    const [formData, setFormData] = useState({
        username: '',
        business_name: '',
        tax_rate: '',
        phone: '',
        email: '',
        full_name: '',
        business_address: '',
        business_type: '',
        tax_id: '',
        store_email: '',
        store_phone: '',
        bank_account: '',
        bank_name: '',
        account_name: '',
        invoice_notes: '',
        invoice_terms: '',
        monthly_target: '',
        password: '',
        confirm_password: '',
        current_password: ''
    });
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState({ type: '', text: '' });

    // Password Change State
    const [isChangingPassword, setIsChangingPassword] = useState(false);
    const [passwordStep, setPasswordStep] = useState('initial'); // 'initial', 'verify', 'update'

    // Table Management State
    const [tables, setTables] = useState([]);
    const [showTableModal, setShowTableModal] = useState(false);
    const [editingTable, setEditingTable] = useState(null);
    const [tableFormData, setTableFormData] = useState({
        table_number: '',
        table_name: '',
        capacity: 4,
        is_active: true
    });
    const [tableMessage, setTableMessage] = useState({ type: '', text: '' });

    useEffect(() => {
        if (currentUser) {
            setFormData(prev => ({
                ...prev,
                username: currentUser.username,
                business_name: currentUser.business_name || '',
                tax_rate: currentUser.tax_rate || 0,
                phone: currentUser.phone || '',
                email: currentUser.email || '',
                full_name: currentUser.full_name || '',
                business_address: currentUser.business_address || '',
                business_type: currentUser.business_type || '',
                tax_id: currentUser.tax_id || '',
                store_email: currentUser.store_email || '',
                store_phone: currentUser.store_phone || '',
                bank_account: currentUser.bank_account || '',
                bank_name: currentUser.bank_name || '',
                account_name: currentUser.account_name || '',
                invoice_notes: currentUser.invoice_notes || '',
                invoice_terms: currentUser.invoice_terms || '',
                monthly_target: currentUser.monthly_target || ''
            }));
            fetchTables();
        }
    }, [currentUser]);

    const fetchTables = async () => {
        try {
            const response = await api.get('/tables');
            setTables(response.data);
        } catch (error) {
            console.error('Error fetching tables:', error);
        }
    };

    const handleTableSubmit = async (e) => {
        e.preventDefault();
        setTableMessage({ type: '', text: '' });

        try {
            if (editingTable) {
                await api.put(`/tables/${editingTable.id}`, tableFormData);
                setTableMessage({ type: 'success', text: 'Table updated successfully' });
            } else {
                await api.post('/tables', tableFormData);
                setTableMessage({ type: 'success', text: 'Table created successfully' });
            }
            fetchTables();
            setShowTableModal(false);
            resetTableForm();
        } catch (error) {
            setTableMessage({ type: 'error', text: error.response?.data?.detail || 'Error saving table' });
        }
    };

    const handleDeleteTable = async (tableId) => {
        if (!window.confirm('Are you sure you want to delete this table?')) return;

        try {
            await api.delete(`/tables/${tableId}`);
            setTableMessage({ type: 'success', text: 'Table deleted successfully' });
            fetchTables();
            setTimeout(() => setTableMessage({ type: '', text: '' }), 3000);
        } catch (error) {
            setTableMessage({ type: 'error', text: 'Error deleting table' });
        }
    };

    const openTableModal = (table = null) => {
        if (table) {
            setEditingTable(table);
            setTableFormData({
                table_number: table.table_number,
                table_name: table.table_name || '',
                capacity: table.capacity,
                is_active: table.is_active
            });
        } else {
            resetTableForm();
        }
        setShowTableModal(true);
    };

    const resetTableForm = () => {
        setEditingTable(null);
        setTableFormData({
            table_number: '',
            table_name: '',
            capacity: 4,
            is_active: true
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage({ type: '', text: '' });

        if (formData.password && formData.password !== formData.confirm_password) {
            setMessage({ type: 'error', text: 'Passwords do not match' });
            return;
        }

        setLoading(true);
        try {
            const payload = {
                username: formData.username,
                business_name: formData.business_name,
                tax_rate: parseFloat(formData.tax_rate) || 0,
                phone: formData.phone,
                email: formData.email,
                full_name: formData.full_name,
                business_address: formData.business_address,
                business_type: formData.business_type,
                tax_id: formData.tax_id,
                store_email: formData.store_email,
                store_phone: formData.store_phone,
                bank_account: formData.bank_account,
                bank_name: formData.bank_name,
                account_name: formData.account_name,
                invoice_notes: formData.invoice_notes,
                invoice_terms: formData.invoice_terms,
                monthly_target: parseFloat(formData.monthly_target) || null
            };

            // Include passwords only if new password is being set
            if (formData.password) {
                payload.password = formData.password;
                payload.current_password = formData.current_password;
            }

            const response = await api.put('/users/me', payload);
            setMessage({ type: 'success', text: 'Profile updated successfully!' });

            // Clear password fields and reset state after successful update
            setFormData(prev => ({
                ...prev,
                password: '',
                confirm_password: '',
                current_password: ''
            }));
            setIsChangingPassword(false);
            setPasswordStep('initial');

            setTimeout(() => {
                window.location.reload();
            }, 1000);

        } catch (err) {
            console.error(err);
            setMessage({ type: 'error', text: err.response?.data?.detail || 'Failed to update profile' });
        } finally {
            setLoading(false);
        }
    };

    const TabButton = ({ active, onClick, icon: Icon, children }) => (
        <button
            onClick={onClick}
            style={{
                padding: '10px 16px',
                borderRadius: '6px',
                border: 'none',
                backgroundColor: active ? '#6366f1' : 'transparent',
                color: active ? 'white' : '#64748b',
                fontSize: '14px',
                fontWeight: '500',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                transition: 'all 0.2s'
            }}
        >
            <Icon size={16} /> {children}
        </button>
    );

    const ShortcutItem = ({ keys, description }) => (
        <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '12px 16px',
            backgroundColor: '#f8fafc',
            borderRadius: '8px',
            border: '1px solid #e2e8f0'
        }}>
            <span style={{ fontSize: '14px', color: '#334155' }}>{description}</span>
            <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                {keys.map((key, index) => (
                    <React.Fragment key={key}>
                        {index > 0 && <span style={{ color: '#94a3b8', fontSize: '12px' }}>+</span>}
                        <kbd style={{
                            padding: '4px 8px',
                            backgroundColor: 'white',
                            border: '1px solid #cbd5e1',
                            borderRadius: '4px',
                            fontSize: '12px',
                            fontWeight: '500',
                            fontFamily: 'system-ui, -apple-system, sans-serif',
                            color: '#1e293b',
                            boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
                        }}>
                            {key}
                        </kbd>
                    </React.Fragment>
                ))}
            </div>
        </div>
    );

    return (
        <div className="page-container" style={{ backgroundColor: '#f8fafc' }}>
            <div className="header-section" style={{ backgroundColor: 'white', borderBottom: '1px solid #e2e8f0' }}>
                <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-indigo-600 flex items-center justify-center rounded shadow-sm">
                        <SettingsIcon size={20} className="text-white" />
                    </div>
                    <div>
                        <h1 style={{ fontSize: '24px', fontWeight: '600', color: '#1e293b', margin: 0 }}>Settings</h1>
                        <p style={{ fontSize: '14px', color: '#64748b', marginTop: '2px' }}>Manage your business and account settings</p>
                    </div>
                </div>
            </div>

            <div className="content-area">
                {message.text && (
                    <div className={`mb-6 p-4 rounded-lg ${message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`} style={{ maxWidth: '1200px', margin: '0 auto 24px' }}>
                        {message.text}
                    </div>
                )}

                {/* Tab Navigation */}
                <div style={{ maxWidth: '1200px', margin: '0 auto', marginBottom: '24px' }}>
                    <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        <TabButton active={activeTab === 'business'} onClick={() => setActiveTab('business')} icon={Building}>Business Details</TabButton>
                        <TabButton active={activeTab === 'invoice'} onClick={() => setActiveTab('invoice')} icon={FileText}>Invoice Settings</TabButton>
                        <TabButton active={activeTab === 'payment'} onClick={() => setActiveTab('payment')} icon={CreditCard}>Payment Details</TabButton>
                        <TabButton active={activeTab === 'tables'} onClick={() => setActiveTab('tables')} icon={Grid3x3}>Tables</TabButton>
                        <TabButton active={activeTab === 'shortcuts'} onClick={() => setActiveTab('shortcuts')} icon={Keyboard}>Shortcuts</TabButton>
                        <TabButton active={activeTab === 'security'} onClick={() => setActiveTab('security')} icon={Lock}>Security</TabButton>
                    </div>
                </div>

                {/* Tab Content */}
                <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                    <form onSubmit={handleSubmit}>
                        
                        {/* Business Details Tab */}
                        {activeTab === 'business' && (
                            <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                                <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#1e293b', marginBottom: '24px' }}>Business Information</h2>
                                
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Business Name *</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.business_name}
                                            onChange={e => setFormData({ ...formData, business_name: e.target.value })}
                                            placeholder="Your Business Name"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Business Type</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.business_type}
                                            onChange={e => setFormData({ ...formData, business_type: e.target.value })}
                                            placeholder="e.g. Restaurant, Retail"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Tax Rate (%)</label>
                                        <input
                                            type="number"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.tax_rate}
                                            onChange={e => setFormData({ ...formData, tax_rate: e.target.value })}
                                            min="0"
                                            step="0.01"
                                            placeholder="10"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Tax ID / GSTIN</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.tax_id}
                                            onChange={e => setFormData({ ...formData, tax_id: e.target.value })}
                                            placeholder="123456789"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Monthly Revenue Target (₹)</label>
                                        <input
                                            type="number"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.monthly_target}
                                            onChange={e => setFormData({ ...formData, monthly_target: e.target.value })}
                                            min="0"
                                            step="1000"
                                            placeholder="100000"
                                        />
                                        <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '4px' }}>Used in dashboard to track monthly progress</p>
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Phone</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.phone}
                                            onChange={e => setFormData({ ...formData, phone: e.target.value })}
                                            placeholder="+1 234 567 890"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Email</label>
                                        <input
                                            type="email"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.email}
                                            onChange={e => setFormData({ ...formData, email: e.target.value })}
                                            placeholder="email@example.com"
                                        />
                                    </div>
                                </div>

                                <div style={{ marginTop: '20px' }}>
                                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Business Address</label>
                                    <textarea
                                        className="input"
                                        style={{ width: '100%' }}
                                        rows="3"
                                        value={formData.business_address}
                                        onChange={e => setFormData({ ...formData, business_address: e.target.value })}
                                        placeholder="123 Main Street, City, State, ZIP"
                                    />
                                </div>

                                <div style={{ marginTop: '24px', paddingTop: '24px', borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'flex-end' }}>
                                    <button
                                        type="submit"
                                        style={{
                                            padding: '10px 24px',
                                            backgroundColor: '#6366f1',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '6px',
                                            fontSize: '14px',
                                            fontWeight: '500',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '8px'
                                        }}
                                        disabled={loading}
                                    >
                                        {loading ? <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span> : <Save size={16} />}
                                        Save Changes
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Invoice Settings Tab */}
                        {activeTab === 'invoice' && (
                            <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                                <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#1e293b', marginBottom: '24px' }}>Invoice Configuration</h2>
                                
                                <div style={{ display: 'grid', gap: '20px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Invoice Footer Notes</label>
                                        <textarea
                                            className="input"
                                            style={{ width: '100%' }}
                                            rows="3"
                                            value={formData.invoice_notes}
                                            onChange={e => setFormData({ ...formData, invoice_notes: e.target.value })}
                                            placeholder="Thank you for your business!"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Terms & Conditions</label>
                                        <textarea
                                            className="input"
                                            style={{ width: '100%' }}
                                            rows="3"
                                            value={formData.invoice_terms}
                                            onChange={e => setFormData({ ...formData, invoice_terms: e.target.value })}
                                            placeholder="Payment due within 30 days"
                                        />
                                    </div>
                                </div>

                                <div style={{ marginTop: '24px', paddingTop: '24px', borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'flex-end' }}>
                                    <button
                                        type="submit"
                                        style={{
                                            padding: '10px 24px',
                                            backgroundColor: '#6366f1',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '6px',
                                            fontSize: '14px',
                                            fontWeight: '500',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '8px'
                                        }}
                                        disabled={loading}
                                    >
                                        {loading ? <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span> : <Save size={16} />}
                                        Save Changes
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Payment Details Tab */}
                        {activeTab === 'payment' && (
                            <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                                <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#1e293b', marginBottom: '24px' }}>Payment Information</h2>
                                
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '20px' }}>
                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Bank Name</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.bank_name}
                                            onChange={e => setFormData({ ...formData, bank_name: e.target.value })}
                                            placeholder="Bank Name"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Account Name</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.account_name}
                                            onChange={e => setFormData({ ...formData, account_name: e.target.value })}
                                            placeholder="Account Holder Name"
                                        />
                                    </div>

                                    <div>
                                        <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Account Number</label>
                                        <input
                                            type="text"
                                            className="input"
                                            style={{ width: '100%' }}
                                            value={formData.bank_account}
                                            onChange={e => setFormData({ ...formData, bank_account: e.target.value })}
                                            placeholder="1234567890"
                                        />
                                    </div>
                                </div>

                                <div style={{ marginTop: '24px', paddingTop: '24px', borderTop: '1px solid #e2e8f0', display: 'flex', justifyContent: 'flex-end' }}>
                                    <button
                                        type="submit"
                                        style={{
                                            padding: '10px 24px',
                                            backgroundColor: '#6366f1',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '6px',
                                            fontSize: '14px',
                                            fontWeight: '500',
                                            cursor: 'pointer',
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: '8px'
                                        }}
                                        disabled={loading}
                                    >
                                        {loading ? <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span> : <Save size={16} />}
                                        Save Changes
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Security Tab */}
                        {activeTab === 'security' && (
                            <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                                <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#1e293b', marginBottom: '24px' }}>Security Settings</h2>
                                
                                {!isChangingPassword ? (
                                    <div>
                                        <p style={{ fontSize: '14px', color: '#64748b', marginBottom: '16px' }}>Manage your account password and security settings</p>
                                        <button
                                            type="button"
                                            onClick={() => {
                                                setIsChangingPassword(true);
                                                setPasswordStep('verify');
                                                setMessage({ type: '', text: '' });
                                            }}
                                            style={{
                                                padding: '10px 24px',
                                                backgroundColor: '#6366f1',
                                                color: 'white',
                                                border: 'none',
                                                borderRadius: '6px',
                                                fontSize: '14px',
                                                fontWeight: '500',
                                                cursor: 'pointer'
                                            }}
                                        >
                                            Change Password
                                        </button>
                                    </div>
                                ) : (
                                    <div style={{ backgroundColor: '#f8fafc', padding: '24px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                                            <h4 style={{ fontSize: '16px', fontWeight: '600', color: '#1e293b' }}>Change Password</h4>
                                            <button
                                                type="button"
                                                onClick={() => {
                                                    setIsChangingPassword(false);
                                                    setPasswordStep('initial');
                                                    setFormData(prev => ({ ...prev, password: '', confirm_password: '', current_password: '' }));
                                                    setMessage({ type: '', text: '' });
                                                }}
                                                style={{
                                                    fontSize: '13px',
                                                    color: '#64748b',
                                                    background: 'none',
                                                    border: 'none',
                                                    cursor: 'pointer'
                                                }}
                                            >
                                                Cancel
                                            </button>
                                        </div>

                                        {passwordStep === 'verify' && (
                                            <div>
                                                <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Current Password</label>
                                                <div style={{ display: 'flex', gap: '8px' }}>
                                                    <input
                                                        type="password"
                                                        className="input"
                                                        style={{ flex: 1 }}
                                                        value={formData.current_password}
                                                        onChange={e => setFormData({ ...formData, current_password: e.target.value })}
                                                        placeholder="Enter current password to verify"
                                                    />
                                                    <button
                                                        type="button"
                                                        className="btn"
                                                        disabled={loading}
                                                        onClick={async () => {
                                                            if (!formData.current_password) return;
                                                            try {
                                                                setLoading(true);
                                                                await api.post('/users/verify-password', { password: formData.current_password });
                                                                setPasswordStep('update');
                                                                setMessage({ type: 'success', text: 'Password verified. Enter new password.' });
                                                            } catch (err) {
                                                                setMessage({ type: 'error', text: 'Incorrect password.' });
                                                            } finally {
                                                                setLoading(false);
                                                            }
                                                        }}
                                                        style={{
                                                            padding: '10px 20px',
                                                            backgroundColor: '#6366f1',
                                                            color: 'white',
                                                            border: 'none',
                                                            borderRadius: '6px',
                                                            fontSize: '14px',
                                                            fontWeight: '500',
                                                            cursor: 'pointer'
                                                        }}
                                                    >
                                                        {loading ? '...' : 'Verify'}
                                                    </button>
                                                </div>
                                            </div>
                                        )}

                                        {passwordStep === 'update' && (
                                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '16px' }}>
                                                <div>
                                                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>New Password</label>
                                                    <div style={{ position: 'relative' }}>
                                                        <input
                                                            type={showPassword ? "text" : "password"}
                                                            className="input"
                                                            style={{ width: '100%', paddingRight: '40px' }}
                                                            value={formData.password}
                                                            onChange={e => setFormData({ ...formData, password: e.target.value })}
                                                            placeholder="New password"
                                                        />
                                                        <button
                                                            type="button"
                                                            onClick={() => setShowPassword(!showPassword)}
                                                            style={{
                                                                position: 'absolute',
                                                                right: '12px',
                                                                top: '50%',
                                                                transform: 'translateY(-50%)',
                                                                background: 'none',
                                                                border: 'none',
                                                                cursor: 'pointer',
                                                                color: '#94a3b8'
                                                            }}
                                                        >
                                                            {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                                        </button>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Confirm Password</label>
                                                    <input
                                                        type="password"
                                                        className="input"
                                                        style={{ width: '100%' }}
                                                        value={formData.confirm_password}
                                                        onChange={e => setFormData({ ...formData, confirm_password: e.target.value })}
                                                        placeholder="Confirm new password"
                                                    />
                                                </div>
                                            </div>
                                        )}

                                        {passwordStep === 'update' && (
                                            <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end' }}>
                                                <button
                                                    type="submit"
                                                    style={{
                                                        padding: '10px 24px',
                                                        backgroundColor: '#6366f1',
                                                        color: 'white',
                                                        border: 'none',
                                                        borderRadius: '6px',
                                                        fontSize: '14px',
                                                        fontWeight: '500',
                                                        cursor: 'pointer',
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: '8px'
                                                    }}
                                                    disabled={loading}
                                                >
                                                    {loading ? <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span> : <Save size={16} />}
                                                    Update Password
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}
                    </form>

                    {/* Shortcuts Tab - Outside form */}
                    {activeTab === 'shortcuts' && (
                        <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                            <div style={{ marginBottom: '24px' }}>
                                <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#1e293b', marginBottom: '8px' }}>Keyboard Shortcuts Guide</h2>
                                <p style={{ fontSize: '14px', color: '#64748b' }}>Use these keyboard shortcuts for faster navigation and operations</p>
                            </div>

                            {/* Navigation Shortcuts */}
                            <div style={{ marginBottom: '32px' }}>
                                <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#1e293b', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <span style={{ width: '4px', height: '20px', backgroundColor: '#6366f1', borderRadius: '2px' }}></span>
                                    Navigation Shortcuts
                                </h3>
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
                                    <ShortcutItem keys={['Alt', 'D']} description="Go to Dashboard" />
                                    <ShortcutItem keys={['Alt', 'B']} description="Go to Billing (POS)" />
                                    <ShortcutItem keys={['Alt', 'H']} description="Go to History" />
                                    <ShortcutItem keys={['Alt', 'I']} description="Go to Items" />
                                    <ShortcutItem keys={['Alt', 'S']} description="Go to Settings" />
                                </div>
                            </div>

                            {/* Action Shortcuts */}
                            <div style={{ marginBottom: '32px' }}>
                                <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#1e293b', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <span style={{ width: '4px', height: '20px', backgroundColor: '#10b981', borderRadius: '2px' }}></span>
                                    Action Shortcuts
                                </h3>
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
                                    <ShortcutItem keys={['Ctrl', '/']} description="Focus Search Input" />
                                    <ShortcutItem keys={['Alt', 'Enter']} description="Toggle Fullscreen" />
                                    <ShortcutItem keys={['Escape']} description="Clear Input / Close Modal" />
                                </div>
                            </div>

                            {/* System Shortcuts */}
                            <div style={{ marginBottom: '32px' }}>
                                <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#1e293b', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <span style={{ width: '4px', height: '20px', backgroundColor: '#f59e0b', borderRadius: '2px' }}></span>
                                    System Shortcuts
                                </h3>
                                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
                                    <ShortcutItem keys={['Alt', 'Q']} description="Logout" />
                                </div>
                            </div>

                            {/* Tips */}
                            <div style={{ backgroundColor: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: '8px', padding: '16px' }}>
                                <h4 style={{ fontSize: '14px', fontWeight: '600', color: '#0369a1', marginBottom: '8px' }}>💡 Tips</h4>
                                <ul style={{ fontSize: '13px', color: '#0c4a6e', margin: 0, paddingLeft: '20px', lineHeight: '1.8' }}>
                                    <li>Shortcuts won't work when typing in input fields</li>
                                    <li>Press <kbd style={{ backgroundColor: '#e0f2fe', padding: '2px 6px', borderRadius: '4px', fontFamily: 'monospace' }}>Escape</kbd> to exit input fields and enable shortcuts</li>
                                    <li>Use <kbd style={{ backgroundColor: '#e0f2fe', padding: '2px 6px', borderRadius: '4px', fontFamily: 'monospace' }}>Alt + Enter</kbd> for a distraction-free fullscreen experience</li>
                                    <li>Navigate quickly between pages using <kbd style={{ backgroundColor: '#e0f2fe', padding: '2px 6px', borderRadius: '4px', fontFamily: 'monospace' }}>Alt</kbd> + letter shortcuts</li>
                                </ul>
                            </div>
                        </div>
                    )}

                    {/* Tables Tab - Outside form */}
                    {activeTab === 'tables' && (
                        <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px' }}>
                                <h2 style={{ fontSize: '18px', fontWeight: '600', color: '#1e293b' }}>Table Management</h2>
                                <button
                                    onClick={() => openTableModal()}
                                    style={{
                                        padding: '10px 20px',
                                        backgroundColor: '#6366f1',
                                        color: 'white',
                                        border: 'none',
                                        borderRadius: '6px',
                                        fontSize: '14px',
                                        fontWeight: '500',
                                        cursor: 'pointer',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '8px'
                                    }}
                                >
                                    <Plus size={16} />
                                    Add Table
                                </button>
                            </div>

                            {tableMessage.text && (
                                <div className={`mb-4 p-3 rounded-lg ${tableMessage.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
                                    {tableMessage.text}
                                </div>
                            )}

                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '16px' }}>
                                {tables.map(table => (
                                    <div key={table.id} style={{ border: '1px solid #e2e8f0', borderRadius: '8px', padding: '20px' }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
                                            <div>
                                                <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#1e293b', marginBottom: '4px' }}>{table.table_name}</h3>
                                                <p style={{ fontSize: '13px', color: '#64748b' }}>Number: {table.table_number}</p>
                                                <p style={{ fontSize: '13px', color: '#64748b' }}>Capacity: {table.capacity} people</p>
                                            </div>
                                            <span style={{
                                                padding: '4px 12px',
                                                borderRadius: '12px',
                                                fontSize: '12px',
                                                fontWeight: '500',
                                                backgroundColor: table.is_active ? '#dcfce7' : '#f1f5f9',
                                                color: table.is_active ? '#15803d' : '#64748b'
                                            }}>
                                                {table.is_active ? 'Active' : 'Inactive'}
                                            </span>
                                        </div>
                                        <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
                                            <button
                                                onClick={() => openTableModal(table)}
                                                style={{
                                                    flex: 1,
                                                    padding: '8px',
                                                    backgroundColor: '#eef2ff',
                                                    color: '#6366f1',
                                                    border: 'none',
                                                    borderRadius: '6px',
                                                    fontSize: '13px',
                                                    fontWeight: '500',
                                                    cursor: 'pointer',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    gap: '6px'
                                                }}
                                            >
                                                <Edit2 size={14} />
                                                Edit
                                            </button>
                                            <button
                                                onClick={() => handleDeleteTable(table.id)}
                                                style={{
                                                    flex: 1,
                                                    padding: '8px',
                                                    backgroundColor: '#fef2f2',
                                                    color: '#ef4444',
                                                    border: 'none',
                                                    borderRadius: '6px',
                                                    fontSize: '13px',
                                                    fontWeight: '500',
                                                    cursor: 'pointer',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    gap: '6px'
                                                }}
                                            >
                                                <Trash2 size={14} />
                                                Delete
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {tables.length === 0 && (
                                <div style={{ textAlign: 'center', padding: '48px 20px', color: '#94a3b8' }}>
                                    <Grid3x3 size={48} style={{ margin: '0 auto 12px', opacity: 0.3 }} />
                                    <p>No tables configured yet. Click "Add Table" to get started.</p>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* Table Modal */}
            {showTableModal && (
                <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50, padding: '16px' }}>
                    <div style={{ backgroundColor: 'white', borderRadius: '8px', padding: '24px', maxWidth: '500px', width: '100%' }}>
                        <h3 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '20px' }}>{editingTable ? 'Edit Table' : 'Add New Table'}</h3>
                        <form onSubmit={handleTableSubmit}>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                                <div>
                                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Table Number *</label>
                                    <input
                                        type="text"
                                        className="input"
                                        style={{ width: '100%' }}
                                        value={tableFormData.table_number}
                                        onChange={e => setTableFormData({ ...tableFormData, table_number: e.target.value })}
                                        required
                                        placeholder="e.g., 1, 2, A1"
                                    />
                                </div>
                                <div>
                                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Table Name</label>
                                    <input
                                        type="text"
                                        className="input"
                                        style={{ width: '100%' }}
                                        value={tableFormData.table_name}
                                        onChange={e => setTableFormData({ ...tableFormData, table_name: e.target.value })}
                                        placeholder="e.g., VIP Table, Corner Table"
                                    />
                                </div>
                                <div>
                                    <label style={{ display: 'block', fontSize: '13px', fontWeight: '500', color: '#64748b', marginBottom: '8px' }}>Capacity (people)</label>
                                    <input
                                        type="number"
                                        className="input"
                                        style={{ width: '100%' }}
                                        value={tableFormData.capacity}
                                        onChange={e => setTableFormData({ ...tableFormData, capacity: parseInt(e.target.value) })}
                                        min="1"
                                        required
                                    />
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <input
                                        type="checkbox"
                                        id="table_active"
                                        checked={tableFormData.is_active}
                                        onChange={e => setTableFormData({ ...tableFormData, is_active: e.target.checked })}
                                        style={{ width: '16px', height: '16px' }}
                                    />
                                    <label htmlFor="table_active" style={{ fontSize: '13px', fontWeight: '500', color: '#64748b' }}>Active</label>
                                </div>
                            </div>
                            <div style={{ display: 'flex', gap: '12px', marginTop: '24px' }}>
                                <button
                                    type="button"
                                    onClick={() => { setShowTableModal(false); resetTableForm(); }}
                                    style={{
                                        flex: 1,
                                        padding: '10px 24px',
                                        border: '1px solid #e2e8f0',
                                        borderRadius: '6px',
                                        fontSize: '14px',
                                        fontWeight: '500',
                                        cursor: 'pointer',
                                        backgroundColor: 'white',
                                        color: '#64748b'
                                    }}
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    style={{
                                        flex: 1,
                                        padding: '10px 24px',
                                        backgroundColor: '#6366f1',
                                        color: 'white',
                                        border: 'none',
                                        borderRadius: '6px',
                                        fontSize: '14px',
                                        fontWeight: '500',
                                        cursor: 'pointer'
                                    }}
                                >
                                    {editingTable ? 'Update' : 'Create'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Settings;
