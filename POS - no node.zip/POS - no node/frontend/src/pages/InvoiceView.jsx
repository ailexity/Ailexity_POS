import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import { ArrowLeft, Printer, Share2, CheckCircle, XCircle } from 'lucide-react';
import { numberToWords, calculateTaxBreakdown, roundOff, formatInvoiceDate, formatInvoiceTime } from '../utils/invoiceHelpers';
import '../styles/invoice.css';

const InvoiceView = () => {
    const { invoiceId } = useParams();
    const navigate = useNavigate();
    const [invoice, setInvoice] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchInvoice();
    }, [invoiceId]);

    const fetchInvoice = async () => {
        try {
            setLoading(true);
            const response = await api.get(`/invoices/`);
            const foundInvoice = response.data.find(inv => inv.id === invoiceId);
            
            if (foundInvoice) {
                setInvoice(foundInvoice);
            } else {
                setError('Invoice not found');
            }
        } catch (err) {
            setError('Failed to load invoice');
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handlePrint = () => {
        window.print();
    };

    const handleShare = () => {
        const url = window.location.href;
        if (navigator.share) {
            navigator.share({
                title: `Invoice ${invoice?.invoice_number}`,
                text: `View invoice for ₹${invoice?.total_amount.toFixed(2)}`,
                url: url
            });
        } else {
            navigator.clipboard.writeText(url);
            alert('Invoice link copied to clipboard!');
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading invoice...</p>
                </div>
            </div>
        );
    }

    if (error || !invoice) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <p className="text-red-600 text-lg mb-4">{error || 'Invoice not found'}</p>
                    <button
                        onClick={() => navigate('/dashboard')}
                        className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
                    >
                        Go to Dashboard
                    </button>
                </div>
            </div>
        );
    }

    const invoiceDate = new Date(invoice.created_at);
    
    // Calculate totals and tax breakdown
    const subtotal = invoice.items?.reduce((sum, item) => sum + (item.unit_price * item.quantity), 0) || 0;
    const taxRate = invoice.items?.[0]?.tax_amount ? 
        ((invoice.items[0].tax_amount / (invoice.items[0].unit_price * invoice.items[0].quantity)) * 100) : 0;
    const taxBreakdown = calculateTaxBreakdown(subtotal, taxRate, false);
    const totalTax = taxBreakdown.cgst + taxBreakdown.sgst + taxBreakdown.igst;
    const grandTotalBeforeRound = subtotal + totalTax;
    const { roundedAmount: grandTotal, roundOffValue } = roundOff(grandTotalBeforeRound);
    const amountInWords = numberToWords(grandTotal);

    return (
        <div className="min-h-screen bg-gray-100 py-8">
            {/* Action Buttons - Hidden on print */}
            <div className="max-w-[210mm] mx-auto px-4 mb-6 print:hidden">
                <div className="flex justify-between items-center">
                    <button
                        onClick={() => navigate(-1)}
                        className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-all"
                    >
                        <ArrowLeft size={18} />
                        <span>Back</span>
                    </button>
                    <div className="flex gap-2">
                        <button
                            onClick={handleShare}
                            className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-all"
                        >
                            <Share2 size={18} />
                            <span>Share</span>
                        </button>
                        <button
                            onClick={handlePrint}
                            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-all"
                        >
                            <Printer size={18} />
                            <span>Print</span>
                        </button>
                    </div>
                </div>
            </div>

            {/* A4 Invoice Template */}
            <div className="invoice-a4-container">
                <div className="invoice-a4-page" style={{ fontFamily: 'Arial, sans-serif', backgroundColor: 'white' }}>
                    {/* Header - Simple colored bar */}
                    <div style={{ background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)', padding: '24px 32px', marginBottom: '0' }}>
                        <div className="flex justify-between items-center">
                            <div>
                                <h1 style={{ fontSize: '28px', fontWeight: 'bold', color: '#1e293b', margin: 0 }}>
                                    {invoice.business_name || 'Business Name'}
                                </h1>
                            </div>
                            <div className="text-right">
                                <h2 style={{ fontSize: '20px', fontWeight: 'bold', color: 'white', margin: 0 }}>TAX INVOICE</h2>
                                <p style={{ fontSize: '14px', color: 'rgba(255,255,255,0.9)', marginTop: '4px' }}>
                                    {invoice.invoice_number}
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Content Area */}
                    <div style={{ padding: '32px', flex: '1', display: 'flex', flexDirection: 'column' }}>
                        {/* Bill To Section */}
                        <div style={{ marginBottom: '24px' }}>
                            <h3 style={{ fontSize: '11px', fontWeight: 'bold', color: '#64748b', textTransform: 'uppercase', marginBottom: '8px' }}>
                                BILL TO
                            </h3>
                            <p style={{ fontSize: '14px', fontWeight: '600', color: '#1e293b', margin: 0 }}>
                                {invoice.customer_name || 'Walk-in Customer'}
                            </p>
                        </div>

                        {/* Invoice Details Section */}
                        <div style={{ marginBottom: '24px' }}>
                            <h3 style={{ fontSize: '11px', fontWeight: 'bold', color: '#64748b', textTransform: 'uppercase', marginBottom: '12px' }}>
                                INVOICE DETAILS
                            </h3>
                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px', fontSize: '13px' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: '#64748b' }}>Invoice No:</span>
                                    <span style={{ fontWeight: '600', color: '#1e293b', textAlign: 'right' }}>{invoice.invoice_number}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: '#64748b' }}>Payment Status:</span>
                                    <span style={{ fontWeight: '600', color: '#1e293b', textAlign: 'right', display: 'flex', alignItems: 'center', gap: '4px' }}>
                                        {invoice.payment_status === 'Paid' ? <CheckCircle size={14} color="#10b981" /> : <XCircle size={14} color="#ef4444" />}
                                        {invoice.payment_status || 'Paid'}
                                    </span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: '#64748b' }}>Date:</span>
                                    <span style={{ fontWeight: '600', color: '#1e293b', textAlign: 'right' }}>{formatInvoiceDate(invoice.created_at)}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: '#64748b' }}>Time:</span>
                                    <span style={{ fontWeight: '600', color: '#1e293b', textAlign: 'right' }}>{formatInvoiceTime(invoice.created_at)}</span>
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <span style={{ color: '#64748b' }}>Payment Mode:</span>
                                    <span style={{ fontWeight: '600', color: '#1e293b', textAlign: 'right' }}>{invoice.payment_mode || 'Cash'}</span>
                                </div>
                            </div>
                        </div>

                        {/* Items Table */}
                        <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '24px', fontSize: '13px' }}>
                            <thead>
                                <tr style={{ borderBottom: '2px solid #e2e8f0' }}>
                                    <th style={{ textAlign: 'left', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>Sr.</th>
                                    <th style={{ textAlign: 'left', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>Item Description</th>
                                    <th style={{ textAlign: 'center', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>HSN/SAC</th>
                                    <th style={{ textAlign: 'center', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>Qty</th>
                                    <th style={{ textAlign: 'right', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>Rate</th>
                                    <th style={{ textAlign: 'right', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>Taxable Value</th>
                                    <th style={{ textAlign: 'right', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>CGST</th>
                                    <th style={{ textAlign: 'right', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>SGST</th>
                                    <th style={{ textAlign: 'right', padding: '12px 8px', fontWeight: '600', color: '#475569' }}>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {invoice.items && invoice.items.map((item, index) => {
                                    const taxableValue = item.unit_price * item.quantity;
                                    const cgst = item.tax_amount / 2;
                                    const sgst = item.tax_amount / 2;
                                    const amount = taxableValue + item.tax_amount;
                                    
                                    return (
                                        <tr key={index} style={{ borderBottom: '1px solid #f1f5f9' }}>
                                            <td style={{ padding: '12px 8px', color: '#64748b' }}>{index + 1}</td>
                                            <td style={{ padding: '12px 8px', color: '#1e293b', fontWeight: '500' }}>{item.item_name}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'center', color: '#64748b' }}>{item.hsn_code || '-'}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'center', color: '#1e293b' }}>{item.quantity}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'right', color: '#64748b' }}>₹{item.unit_price.toFixed(2)}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'right', fontWeight: '600', color: '#1e293b' }}>₹{taxableValue.toFixed(2)}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'right', color: '#64748b', fontSize: '12px' }}>₹{cgst.toFixed(2)}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'right', color: '#64748b', fontSize: '12px' }}>₹{sgst.toFixed(2)}</td>
                                            <td style={{ padding: '12px 8px', textAlign: 'right', fontWeight: '600', color: '#1e293b' }}>₹{amount.toFixed(2)}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>

                        {/* Totals Summary - Right Aligned */}
                        <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '24px' }}>
                            <div style={{ width: '400px' }}>
                                {/* Subtotal */}
                                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #e2e8f0' }}>
                                    <span style={{ fontSize: '13px', color: '#64748b' }}>Sub Total (Taxable Value):</span>
                                    <span style={{ fontSize: '13px', fontWeight: '600', color: '#1e293b' }}>₹{subtotal.toFixed(2)}</span>
                                </div>
                                
                                {/* Tax Breakdown */}
                                <div style={{ padding: '12px 0' }}>
                                    <p style={{ fontSize: '12px', fontWeight: '600', color: '#1e293b', marginBottom: '8px' }}>Tax Breakdown:</p>
                                    {taxBreakdown.cgst > 0 && (
                                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#64748b', marginBottom: '4px' }}>
                                            <span>CGST @ {taxRate / 2}%:</span>
                                            <span style={{ fontWeight: '500' }}>₹{taxBreakdown.cgst.toFixed(2)}</span>
                                        </div>
                                    )}
                                    {taxBreakdown.sgst > 0 && (
                                        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', color: '#64748b', marginBottom: '4px' }}>
                                            <span>SGST @ {taxRate / 2}%:</span>
                                            <span style={{ fontWeight: '500' }}>₹{taxBreakdown.sgst.toFixed(2)}</span>
                                        </div>
                                    )}
                                </div>
                                
                                {/* Total Tax */}
                                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid #e2e8f0', borderBottom: '1px solid #e2e8f0' }}>
                                    <span style={{ fontSize: '13px', fontWeight: '600', color: '#1e293b' }}>Total Tax:</span>
                                    <span style={{ fontSize: '13px', fontWeight: '600', color: '#1e293b' }}>₹{totalTax.toFixed(2)}</span>
                                </div>
                                
                                {/* Round Off */}
                                {Math.abs(roundOffValue) > 0.01 && (
                                    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0' }}>
                                        <span style={{ fontSize: '13px', color: '#64748b' }}>Round Off:</span>
                                        <span style={{ fontSize: '13px', fontWeight: '500', color: '#1e293b' }}>
                                            {roundOffValue > 0 ? '+' : ''}{roundOffValue.toFixed(2)}
                                        </span>
                                    </div>
                                )}
                                
                                {/* Grand Total */}
                                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderTop: '2px solid #1e293b', marginTop: '8px' }}>
                                    <span style={{ fontSize: '16px', fontWeight: 'bold', color: '#1e293b' }}>Grand Total:</span>
                                    <span style={{ fontSize: '20px', fontWeight: 'bold', color: '#1e293b' }}>₹{grandTotal.toFixed(2)}</span>
                                </div>
                                
                                {/* Amount in Words */}
                                <div style={{ marginTop: '12px', padding: '12px', backgroundColor: '#f8fafc', borderRadius: '4px' }}>
                                    <p style={{ fontSize: '11px', fontWeight: '600', color: '#64748b', marginBottom: '4px' }}>Amount in Words</p>
                                    <p style={{ fontSize: '13px', fontWeight: '600', color: '#1e293b' }}>{amountInWords}</p>
                                </div>
                            </div>
                        </div>

                    </div>

                    {/* Footer - Positioned at bottom */}
                    <div style={{ marginTop: 'auto', textAlign: 'center', padding: '24px 32px', borderTop: '1px solid #e2e8f0' }}>
                        <p style={{ fontSize: '13px', color: '#64748b', marginBottom: '8px' }}>Thank you for your business!</p>
                        <p style={{ fontSize: '12px', color: '#94a3b8' }}>Powered by Ailexity POS</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default InvoiceView;
