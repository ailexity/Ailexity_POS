import React, { useEffect, useState } from 'react';
import api from '../api';
import { DollarSign, ShoppingBag, TrendingUp, Package, LayoutDashboard, Calendar, ArrowUp, ArrowDown, Clock, Users, CreditCard, AlertTriangle, Activity, Target, Zap, BarChart3 } from 'lucide-react';
import AIAssistant from '../components/AIAssistant';

const Dashboard = () => {
    const [stats, setStats] = useState({
        totalRevenue: 0,
        totalOrders: 0,
        totalItems: 0,
        avgOrderValue: 0,
        todayRevenue: 0,
        todayOrders: 0,
        yesterdayRevenue: 0,
        yesterdayOrders: 0,
        weekRevenue: 0,
        weekOrders: 0,
        monthRevenue: 0,
        monthOrders: 0,
        lowStockItems: 0,
        topCategories: [],
        recentInvoices: [],
        hourlyData: Array(24).fill(0),
        paymentModes: {}
    });
    const [loading, setLoading] = useState(true);
    const [currentTime, setCurrentTime] = useState(new Date());
    const [monthlyTarget, setMonthlyTarget] = useState(0);

    useEffect(() => {
        fetchStats();

        // Update time every second
        const timeInterval = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);

        // Auto-refresh stats every 30 seconds
        const statsInterval = setInterval(() => {
            fetchStats();
        }, 30000);

        return () => {
            clearInterval(timeInterval);
            clearInterval(statsInterval);
        };
    }, []);

    const fetchStats = async () => {
        try {
            setLoading(true);
            
            // Fetch user settings to get monthly target
            try {
                const userRes = await api.get('/users/me');
                if (userRes.data.monthly_target) {
                    setMonthlyTarget(userRes.data.monthly_target);
                }
            } catch (e) {
                console.error('Error fetching user settings:', e);
            }
            
            // Fetch invoices (filtered by admin_id automatically by backend)
            const invoicesRes = await api.get('/invoices/?limit=1000');
            const invoices = invoicesRes.data;

            // Fetch items (filtered by admin_id automatically by backend)
            const itemsRes = await api.get('/items/');
            const items = itemsRes.data;

            // Calculate total revenue
            const totalRevenue = invoices.reduce((sum, inv) => sum + inv.total_amount, 0);

            // Calculate today's stats
            const today = new Date();
            today.setHours(0, 0, 0, 0);

            const todayInvoices = invoices.filter(inv => {
                const invDate = new Date(inv.created_at);
                invDate.setHours(0, 0, 0, 0);
                return invDate.getTime() === today.getTime();
            });

            const todayRevenue = todayInvoices.reduce((sum, inv) => sum + inv.total_amount, 0);

            // Calculate yesterday's stats
            const yesterday = new Date(today);
            yesterday.setDate(yesterday.getDate() - 1);

            const yesterdayInvoices = invoices.filter(inv => {
                const invDate = new Date(inv.created_at);
                invDate.setHours(0, 0, 0, 0);
                return invDate.getTime() === yesterday.getTime();
            });

            const yesterdayRevenue = yesterdayInvoices.reduce((sum, inv) => sum + inv.total_amount, 0);

            // Calculate this week's stats
            const weekStart = new Date(today);
            weekStart.setDate(today.getDate() - today.getDay());

            const weekInvoices = invoices.filter(inv => {
                const invDate = new Date(inv.created_at);
                return invDate >= weekStart;
            });

            const weekRevenue = weekInvoices.reduce((sum, inv) => sum + inv.total_amount, 0);

            // Calculate this month's stats
            const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

            const monthInvoices = invoices.filter(inv => {
                const invDate = new Date(inv.created_at);
                return invDate >= monthStart;
            });

            const monthRevenue = monthInvoices.reduce((sum, inv) => sum + inv.total_amount, 0);

            // Calculate average order value
            const avgOrderValue = invoices.length > 0 ? totalRevenue / invoices.length : 0;

            // Count low stock items (less than 10)
            const lowStockItems = items.filter(item => item.limit_stock && item.stock_quantity < 10).length;

            // Calculate top categories
            const categoryMap = {};
            items.forEach(item => {
                categoryMap[item.category] = (categoryMap[item.category] || 0) + 1;
            });
            const topCategories = Object.entries(categoryMap)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 5)
                .map(([name, count]) => ({ name, count }));

            // Get recent invoices
            const recentInvoices = invoices.slice(-5).reverse();

            // Calculate payment mode distribution
            const paymentModes = {};
            invoices.forEach(inv => {
                const mode = inv.payment_mode || 'Cash';
                paymentModes[mode] = (paymentModes[mode] || 0) + 1;
            });

            // Calculate hourly distribution for today
            const hourlyData = Array(24).fill(0);
            todayInvoices.forEach(inv => {
                const hour = new Date(inv.created_at).getHours();
                hourlyData[hour] += inv.total_amount;
            });

            setStats({
                totalRevenue,
                totalOrders: invoices.length,
                totalItems: items.length,
                avgOrderValue,
                todayRevenue,
                todayOrders: todayInvoices.length,
                yesterdayRevenue,
                yesterdayOrders: yesterdayInvoices.length,
                weekRevenue,
                weekOrders: weekInvoices.length,
                monthRevenue,
                monthOrders: monthInvoices.length,
                lowStockItems,
                topCategories,
                recentInvoices,
                hourlyData,
                paymentModes
            });
        } catch (e) {
            console.error('Error fetching stats:', e);
        } finally {
            setLoading(false);
        }
    };

    const calculateTrend = (current, previous) => {
        if (previous === 0) return { trend: current > 0 ? 'up' : null, value: current > 0 ? '+100%' : '—' };
        const change = ((current - previous) / previous) * 100;
        return {
            trend: change > 0 ? 'up' : change < 0 ? 'down' : 'neutral',
            value: `${change > 0 ? '+' : ''}${change.toFixed(1)}%`
        };
    };

    const todayTrend = calculateTrend(stats.todayRevenue, stats.yesterdayRevenue);
    const orderTrend = calculateTrend(stats.todayOrders, stats.yesterdayOrders);

    const formatCurrency = (amount) => {
        if (amount >= 100000) return `₹${(amount / 100000).toFixed(2)}L`;
        if (amount >= 1000) return `₹${(amount / 1000).toFixed(1)}K`;
        return `₹${amount.toFixed(2)}`;
    };

    const getGreeting = () => {
        const hour = currentTime.getHours();
        if (hour < 12) return 'Good Morning';
        if (hour < 17) return 'Good Afternoon';
        return 'Good Evening';
    };

    // Simple bar chart component - 12 bars for 24 hours (2-hour intervals)
    const MiniBarChart = ({ data, maxHeight = 40 }) => {
        // Ensure we have valid data
        const chartData = data && data.length >= 24 ? data : Array(24).fill(0);
        
        // Combine into 2-hour intervals (12 bars total)
        const combinedData = [];
        for (let i = 0; i < 24; i += 2) {
            combinedData.push(chartData[i] + chartData[i + 1]);
        }
        
        const max = Math.max(...combinedData, 1);
        const hasData = combinedData.some(v => v > 0);
        
        // Labels for 2-hour intervals
        const labels = ['12AM', '2AM', '4AM', '6AM', '8AM', '10AM', '12PM', '2PM', '4PM', '6PM', '8PM', '10PM'];
        
        return (
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: '4px', height: maxHeight, position: 'relative' }}>
                {combinedData.map((value, i) => (
                    <div
                        key={i}
                        style={{
                            flex: 1,
                            height: value > 0 ? `${Math.max((value / max) * 100, 10)}%` : '8px',
                            minHeight: '8px',
                            background: value > 0 
                                ? 'linear-gradient(180deg, #8b5cf6 0%, #6366f1 100%)' 
                                : '#e2e8f0',
                            borderRadius: '2px 2px 0 0',
                            transition: 'height 0.3s ease'
                        }}
                        title={`${labels[i]} - ${labels[i + 1] || '12AM'}: ₹${value.toFixed(0)}`}
                    />
                ))}
                {!hasData && (
                    <div style={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        fontSize: '12px',
                        color: '#94a3b8',
                        whiteSpace: 'nowrap'
                    }}>
                        No sales today yet
                    </div>
                )}
            </div>
        );
    };

    // Progress ring component
    const ProgressRing = ({ progress, size = 60, strokeWidth = 6, color = '#6366f1' }) => {
        const radius = (size - strokeWidth) / 2;
        const circumference = radius * 2 * Math.PI;
        const offset = circumference - (progress / 100) * circumference;
        
        return (
            <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    fill="none"
                    stroke="#e2e8f0"
                    strokeWidth={strokeWidth}
                />
                <circle
                    cx={size / 2}
                    cy={size / 2}
                    r={radius}
                    fill="none"
                    stroke={color}
                    strokeWidth={strokeWidth}
                    strokeDasharray={circumference}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                    style={{ transition: 'stroke-dashoffset 0.5s ease' }}
                />
            </svg>
        );
    };

    // Calculate target progress using user-defined target or fallback to estimate
    const effectiveMonthlyTarget = monthlyTarget > 0 ? monthlyTarget : (stats.avgOrderValue * 30 * 10);
    const targetProgress = effectiveMonthlyTarget > 0 ? Math.min((stats.monthRevenue / effectiveMonthlyTarget) * 100, 100) : 0;

    if (loading && stats.totalOrders === 0) {
        return (
            <div className="page-container">
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
                    <div style={{ textAlign: 'center' }}>
                        <div style={{
                            width: '48px',
                            height: '48px',
                            border: '4px solid #e2e8f0',
                            borderTop: '4px solid #6366f1',
                            borderRadius: '50%',
                            animation: 'spin 1s linear infinite',
                            margin: '0 auto 16px'
                        }} />
                        <p style={{ color: '#64748b' }}>Loading dashboard...</p>
                    </div>
                </div>
                <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
            </div>
        );
    }

    return (
        <div className="page-container" style={{ background: '#f8fafc' }}>
            {/* Modern Header */}
            <div style={{
                background: '#ffffff',
                borderRadius: '0',
                padding: '24px',
                marginBottom: '24px',
                color: '#1e293b',
                position: 'relative',
                overflow: 'hidden',
                boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
            }}>
                
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', position: 'relative', zIndex: 1 }}>
                    <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
                            <div style={{
                                width: '48px',
                                height: '48px',
                                background: '#6366f1',
                                borderRadius: '0',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}>
                                <LayoutDashboard size={24} color="white" />
                            </div>
                            <div>
                                <h1 style={{ fontSize: '28px', fontWeight: '700', margin: 0, color: '#1e293b' }}>{getGreeting()}!</h1>
                                <p style={{ color: '#64748b', fontSize: '14px', marginTop: '4px' }}>
                                    {currentTime.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                        <div style={{
                            background: '#f1f5f9',
                            borderRadius: '0',
                            padding: '12px 16px'
                        }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#475569' }}>
                                <Clock size={16} />
                                <span style={{ fontSize: '20px', fontWeight: '600', fontFamily: 'monospace', color: '#1e293b' }}>
                                    {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                                </span>
                            </div>
                        </div>
                        <AIAssistant />
                    </div>
                </div>

                {/* Quick Stats Bar */}
                <div style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(4, 1fr)',
                    gap: '16px',
                    marginTop: '20px',
                    position: 'relative',
                    zIndex: 0,
                    overflow: 'hidden'
                }}>
                    <div style={{ background: '#f0fdf4', borderRadius: '0', padding: '16px', border: '1px solid #bbf7d0', overflow: 'hidden' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <div>
                                <p style={{ fontSize: '12px', color: '#166534', marginBottom: '4px' }}>Today's Revenue</p>
                                <p style={{ fontSize: '24px', fontWeight: '700', color: '#15803d' }}>{formatCurrency(stats.todayRevenue)}</p>
                            </div>
                            {todayTrend.trend && (
                                <div style={{
                                    background: todayTrend.trend === 'up' ? '#dcfce7' : '#fee2e2',
                                    borderRadius: '0',
                                    padding: '4px 8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '4px',
                                    fontSize: '12px',
                                    fontWeight: '600',
                                    color: todayTrend.trend === 'up' ? '#16a34a' : '#dc2626'
                                }}>
                                    {todayTrend.trend === 'up' ? <ArrowUp size={14} /> : <ArrowDown size={14} />}
                                    {todayTrend.value}
                                </div>
                            )}
                        </div>
                    </div>
                    <div style={{ background: '#eff6ff', borderRadius: '0', padding: '16px', border: '1px solid #bfdbfe', overflow: 'hidden' }}>
                        <p style={{ fontSize: '12px', color: '#1e40af', marginBottom: '4px' }}>Today's Orders</p>
                        <p style={{ fontSize: '24px', fontWeight: '700', color: '#1d4ed8' }}>{stats.todayOrders}</p>
                    </div>
                    <div style={{ background: '#faf5ff', borderRadius: '0', padding: '16px', border: '1px solid #e9d5ff', overflow: 'hidden' }}>
                        <p style={{ fontSize: '12px', color: '#6b21a8', marginBottom: '4px' }}>Week Revenue</p>
                        <p style={{ fontSize: '24px', fontWeight: '700', color: '#7c3aed' }}>{formatCurrency(stats.weekRevenue)}</p>
                    </div>
                    <div style={{ background: '#fff7ed', borderRadius: '0', padding: '16px', border: '1px solid #fed7aa', overflow: 'hidden' }}>
                        <p style={{ fontSize: '12px', color: '#9a3412', marginBottom: '4px' }}>Month Revenue</p>
                        <p style={{ fontSize: '24px', fontWeight: '700', color: '#ea580c' }}>{formatCurrency(stats.monthRevenue)}</p>
                    </div>
                </div>
            </div>

            <div className="content-area" style={{ padding: 0 }}>
                {/* Main Dashboard Grid */}
                <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px', marginBottom: '24px' }}>
                    
                    {/* Left Column */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                        
                        {/* Today's Activity Card */}
                        <div style={{
                            background: 'white',
                            borderRadius: '0',
                            padding: '24px',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.1)'
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                                    <div style={{
                                        width: '40px',
                                        height: '40px',
                                        background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
                                        borderRadius: '0',
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center'
                                    }}>
                                        <Activity size={20} color="white" />
                                    </div>
                                    <div>
                                        <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>Today's Activity</h3>
                                        <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>Sales throughout the day (24 hours)</p>
                                    </div>
                                </div>
                                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                    <Zap size={14} color="#f59e0b" />
                                    <span style={{ fontSize: '12px', color: '#64748b' }}>Live</span>
                                </div>
                            </div>
                            
                            {/* Hourly Sales Chart */}
                            <div style={{ marginBottom: '16px' }}>
                                <MiniBarChart data={stats.hourlyData} maxHeight={80} />
                                <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '8px', fontSize: '10px', color: '#94a3b8' }}>
                                    <span>12AM</span>
                                    <span>6AM</span>
                                    <span>12PM</span>
                                    <span>6PM</span>
                                    <span>12AM</span>
                                </div>
                            </div>
                            
                            {/* Today vs Yesterday Comparison */}
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                                <div style={{ background: '#f0fdf4', borderRadius: '0', padding: '16px' }}>
                                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                                        <span style={{ fontSize: '12px', color: '#166534', fontWeight: '500' }}>Today</span>
                                        {todayTrend.trend === 'up' && (
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: '#16a34a', fontSize: '12px' }}>
                                                <ArrowUp size={12} />
                                                {todayTrend.value}
                                            </div>
                                        )}
                                    </div>
                                    <p style={{ fontSize: '24px', fontWeight: '700', color: '#15803d', margin: 0 }}>
                                        ₹{stats.todayRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                                    </p>
                                    <p style={{ fontSize: '12px', color: '#22c55e', marginTop: '4px' }}>{stats.todayOrders} orders</p>
                                </div>
                                <div style={{ background: '#f8fafc', borderRadius: '0', padding: '16px' }}>
                                    <span style={{ fontSize: '12px', color: '#64748b', fontWeight: '500' }}>Yesterday</span>
                                    <p style={{ fontSize: '24px', fontWeight: '700', color: '#475569', margin: '8px 0 0' }}>
                                        ₹{stats.yesterdayRevenue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                                    </p>
                                    <p style={{ fontSize: '12px', color: '#94a3b8', marginTop: '4px' }}>{stats.yesterdayOrders} orders</p>
                                </div>
                            </div>
                        </div>

                        {/* Performance Metrics */}
                        <div style={{
                            background: 'white',
                            borderRadius: '0',
                            padding: '24px',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.1)'
                        }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
                                <div style={{
                                    width: '40px',
                                    height: '40px',
                                    background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
                                    borderRadius: '0',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}>
                                    <BarChart3 size={20} color="white" />
                                </div>
                                <div>
                                    <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>Performance Overview</h3>
                                    <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>All-time business metrics</p>
                                </div>
                            </div>

                            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
                                <div style={{ textAlign: 'center', padding: '16px', background: '#fef3c7', borderRadius: '0' }}>
                                    <DollarSign size={24} style={{ color: '#d97706', marginBottom: '8px' }} />
                                    <p style={{ fontSize: '20px', fontWeight: '700', color: '#92400e', margin: 0 }}>
                                        {formatCurrency(stats.totalRevenue)}
                                    </p>
                                    <p style={{ fontSize: '11px', color: '#a16207', marginTop: '4px' }}>Total Revenue</p>
                                </div>
                                <div style={{ textAlign: 'center', padding: '16px', background: '#dbeafe', borderRadius: '0' }}>
                                    <ShoppingBag size={24} style={{ color: '#2563eb', marginBottom: '8px' }} />
                                    <p style={{ fontSize: '20px', fontWeight: '700', color: '#1e40af', margin: 0 }}>
                                        {stats.totalOrders.toLocaleString()}
                                    </p>
                                    <p style={{ fontSize: '11px', color: '#3b82f6', marginTop: '4px' }}>Total Orders</p>
                                </div>
                                <div style={{ textAlign: 'center', padding: '16px', background: '#dcfce7', borderRadius: '0' }}>
                                    <CreditCard size={24} style={{ color: '#16a34a', marginBottom: '8px' }} />
                                    <p style={{ fontSize: '20px', fontWeight: '700', color: '#166534', margin: 0 }}>
                                        ₹{stats.avgOrderValue.toFixed(0)}
                                    </p>
                                    <p style={{ fontSize: '11px', color: '#22c55e', marginTop: '4px' }}>Avg Order</p>
                                </div>
                                <div style={{ textAlign: 'center', padding: '16px', background: '#f3e8ff', borderRadius: '0' }}>
                                    <Package size={24} style={{ color: '#9333ea', marginBottom: '8px' }} />
                                    <p style={{ fontSize: '20px', fontWeight: '700', color: '#7c3aed', margin: 0 }}>
                                        {stats.totalItems}
                                    </p>
                                    <p style={{ fontSize: '11px', color: '#a855f7', marginTop: '4px' }}>Active Items</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Right Column */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
                        
                        {/* Monthly Target */}
                        <div style={{
                            background: 'white',
                            borderRadius: '0',
                            padding: '24px',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.1)'
                        }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
                                <div style={{
                                    width: '40px',
                                    height: '40px',
                                    background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                                    borderRadius: '0',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}>
                                    <Target size={20} color="white" />
                                </div>
                                <div>
                                    <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>Monthly Progress</h3>
                                    <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>Target vs Achieved</p>
                                </div>
                            </div>

                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
                                <div style={{ position: 'relative' }}>
                                    <ProgressRing progress={targetProgress} size={120} strokeWidth={10} color="#10b981" />
                                    <div style={{
                                        position: 'absolute',
                                        top: '50%',
                                        left: '50%',
                                        transform: 'translate(-50%, -50%) rotate(0deg)',
                                        textAlign: 'center'
                                    }}>
                                        <p style={{ fontSize: '24px', fontWeight: '700', color: '#059669', margin: 0 }}>
                                            {targetProgress.toFixed(0)}%
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div style={{ textAlign: 'center' }}>
                                <p style={{ fontSize: '14px', color: '#64748b' }}>
                                    <span style={{ fontWeight: '600', color: '#10b981' }}>{formatCurrency(stats.monthRevenue)}</span>
                                    {' of '}{formatCurrency(effectiveMonthlyTarget)} target
                                </p>
                                {monthlyTarget === 0 && (
                                    <p style={{ fontSize: '11px', color: '#94a3b8', marginTop: '4px' }}>
                                        Set your target in Settings
                                    </p>
                                )}
                            </div>
                        </div>

                        {/* Alerts & Insights */}
                        <div style={{
                            background: 'white',
                            borderRadius: '0',
                            padding: '24px',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.1)'
                        }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
                                <div style={{
                                    width: '40px',
                                    height: '40px',
                                    background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                                    borderRadius: '0',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center'
                                }}>
                                    <AlertTriangle size={20} color="white" />
                                </div>
                                <div>
                                    <h3 style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>Alerts & Insights</h3>
                                    <p style={{ fontSize: '12px', color: '#64748b', margin: 0 }}>Things that need attention</p>
                                </div>
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                                {/* Low Stock Alert */}
                                {stats.lowStockItems > 0 ? (
                                    <div style={{
                                        background: '#fef2f2',
                                        border: '1px solid #fecaca',
                                        borderRadius: '0',
                                        padding: '14px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        <div style={{
                                            width: '36px',
                                            height: '36px',
                                            background: '#fee2e2',
                                            borderRadius: '0',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <Package size={18} color="#dc2626" />
                                        </div>
                                        <div>
                                            <p style={{ fontSize: '13px', fontWeight: '600', color: '#991b1b', margin: 0 }}>
                                                Low Stock Warning
                                            </p>
                                            <p style={{ fontSize: '12px', color: '#b91c1c', margin: 0 }}>
                                                {stats.lowStockItems} item{stats.lowStockItems > 1 ? 's' : ''} below 10 units
                                            </p>
                                        </div>
                                    </div>
                                ) : (
                                    <div style={{
                                        background: '#f0fdf4',
                                        border: '1px solid #bbf7d0',
                                        borderRadius: '0',
                                        padding: '14px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        <div style={{
                                            width: '36px',
                                            height: '36px',
                                            background: '#dcfce7',
                                            borderRadius: '0',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <Package size={18} color="#16a34a" />
                                        </div>
                                        <div>
                                            <p style={{ fontSize: '13px', fontWeight: '600', color: '#166534', margin: 0 }}>
                                                Stock Healthy
                                            </p>
                                            <p style={{ fontSize: '12px', color: '#22c55e', margin: 0 }}>
                                                All items well stocked
                                            </p>
                                        </div>
                                    </div>
                                )}

                                {/* Sales Trend Alerts */}
                                {todayTrend.trend === 'up' && (
                                    <div style={{
                                        background: '#f0fdf4',
                                        border: '1px solid #bbf7d0',
                                        borderRadius: '0',
                                        padding: '14px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        <div style={{
                                            width: '36px',
                                            height: '36px',
                                            background: '#dcfce7',
                                            borderRadius: '0',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <TrendingUp size={18} color="#16a34a" />
                                        </div>
                                        <div>
                                            <p style={{ fontSize: '13px', fontWeight: '600', color: '#166534', margin: 0 }}>
                                                Sales Growing
                                            </p>
                                            <p style={{ fontSize: '12px', color: '#22c55e', margin: 0 }}>
                                                {todayTrend.value} vs yesterday
                                            </p>
                                        </div>
                                    </div>
                                )}

                                {todayTrend.trend === 'down' && (
                                    <div style={{
                                        background: '#fffbeb',
                                        border: '1px solid #fde68a',
                                        borderRadius: '0',
                                        padding: '14px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        <div style={{
                                            width: '36px',
                                            height: '36px',
                                            background: '#fef3c7',
                                            borderRadius: '0',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <TrendingUp size={18} color="#d97706" style={{ transform: 'rotate(180deg)' }} />
                                        </div>
                                        <div>
                                            <p style={{ fontSize: '13px', fontWeight: '600', color: '#92400e', margin: 0 }}>
                                                Sales Down Today
                                            </p>
                                            <p style={{ fontSize: '12px', color: '#d97706', margin: 0 }}>
                                                {todayTrend.value} from yesterday
                                            </p>
                                        </div>
                                    </div>
                                )}

                                {/* No Activity Alert - when no trend (both today and yesterday are 0) */}
                                {!todayTrend.trend && stats.todayRevenue === 0 && (
                                    <div style={{
                                        background: '#f8fafc',
                                        border: '1px solid #e2e8f0',
                                        borderRadius: '0',
                                        padding: '14px',
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: '12px'
                                    }}>
                                        <div style={{
                                            width: '36px',
                                            height: '36px',
                                            background: '#f1f5f9',
                                            borderRadius: '0',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center'
                                        }}>
                                            <Activity size={18} color="#64748b" />
                                        </div>
                                        <div>
                                            <p style={{ fontSize: '13px', fontWeight: '600', color: '#475569', margin: 0 }}>
                                                No Sales Today
                                            </p>
                                            <p style={{ fontSize: '12px', color: '#94a3b8', margin: 0 }}>
                                                Start taking orders to see activity
                                            </p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Bottom Row - Quick Stats */}
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '24px' }}>
                    <div style={{
                        background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)',
                        borderRadius: '0',
                        padding: '24px',
                        color: 'white',
                        position: 'relative',
                        overflow: 'hidden'
                    }}>
                        <div style={{
                            position: 'absolute',
                            top: '-20px',
                            right: '-20px',
                            width: '100px',
                            height: '100px',
                            background: 'rgba(255,255,255,0.1)',
                            borderRadius: '0'
                        }} />
                        <DollarSign size={28} style={{ opacity: 0.8, marginBottom: '12px' }} />
                        <p style={{ fontSize: '12px', opacity: 0.8, marginBottom: '4px' }}>Daily Average Revenue</p>
                        <p style={{ fontSize: '28px', fontWeight: '700', margin: 0 }}>
                            ₹{stats.monthOrders > 0 ? (stats.monthRevenue / new Date().getDate()).toFixed(0) : '0'}
                        </p>
                    </div>

                    <div style={{
                        background: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
                        borderRadius: '0',
                        padding: '24px',
                        color: 'white',
                        position: 'relative',
                        overflow: 'hidden'
                    }}>
                        <div style={{
                            position: 'absolute',
                            top: '-20px',
                            right: '-20px',
                            width: '100px',
                            height: '100px',
                            background: 'rgba(255,255,255,0.1)',
                            borderRadius: '0'
                        }} />
                        <Users size={28} style={{ opacity: 0.8, marginBottom: '12px' }} />
                        <p style={{ fontSize: '12px', opacity: 0.8, marginBottom: '4px' }}>Orders Per Day (This Month)</p>
                        <p style={{ fontSize: '28px', fontWeight: '700', margin: 0 }}>
                            {stats.monthOrders > 0 ? (stats.monthOrders / new Date().getDate()).toFixed(1) : '0'}
                        </p>
                    </div>

                    <div style={{
                        background: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)',
                        borderRadius: '0',
                        padding: '24px',
                        color: 'white',
                        position: 'relative',
                        overflow: 'hidden'
                    }}>
                        <div style={{
                            position: 'absolute',
                            top: '-20px',
                            right: '-20px',
                            width: '100px',
                            height: '100px',
                            background: 'rgba(255,255,255,0.1)',
                            borderRadius: '0'
                        }} />
                        <TrendingUp size={28} style={{ opacity: 0.8, marginBottom: '12px' }} />
                        <p style={{ fontSize: '12px', opacity: 0.8, marginBottom: '4px' }}>Week Growth</p>
                        <p style={{ fontSize: '28px', fontWeight: '700', margin: 0 }}>
                            {stats.weekOrders > 0 ? '+' + ((stats.weekRevenue / Math.max(stats.monthRevenue || 1, 1)) * 100).toFixed(0) : '0'}%
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
