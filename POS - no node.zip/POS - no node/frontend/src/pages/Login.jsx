import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, Eye, EyeOff } from 'lucide-react';
import './Login.css';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [currentSlide, setCurrentSlide] = useState(0);
    const { login } = useAuth();
    const navigate = useNavigate();
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    // Slideshow images - restaurant and retail related
    const slides = [
        {
            image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&q=80',
            tagline: ['Streamline Your Restaurant,', 'Maximize Your Success']
        },
        {
            image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=800&q=80',
            tagline: ['Effortless Point of Sale,', 'Seamless Transactions']
        },
        {
            image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
            tagline: ['Manage Your Retail Store,', 'With Complete Control']
        }
    ];

    // Auto-slide every 3 seconds
    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentSlide((prev) => (prev + 1) % slides.length);
        }, 3000);

        return () => clearInterval(interval);
    }, [slides.length]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            const result = await login(username, password);
            if (result.success) {
                navigate('/');
            } else {
                setError(result.error || 'Invalid credentials');
            }
        } catch (err) {
            setError('Something went wrong. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-wrapper">
            <div className="login-container">
                {/* Left Panel - Branding */}
                <div className="login-left-panel">
                    <div className="login-brand-header">
                        <img src="/ailexity logo.png" alt="Ailexity" className="login-brand-logo" />
                    </div>
                    <div className="login-hero-image">
                        {slides.map((slide, index) => (
                            <img 
                                key={index}
                                src={slide.image} 
                                alt={`Slide ${index + 1}`}
                                className={`slide-image ${index === currentSlide ? 'active' : ''}`}
                            />
                        ))}
                    </div>
                    <div className="login-tagline">
                        <h2>{slides[currentSlide].tagline[0]}</h2>
                        <h2>{slides[currentSlide].tagline[1]}</h2>
                    </div>
                    <div className="login-carousel-dots">
                        {slides.map((_, index) => (
                            <span 
                                key={index}
                                className={`dot ${index === currentSlide ? 'active' : ''}`}
                                onClick={() => setCurrentSlide(index)}
                            />
                        ))}
                    </div>
                </div>

                {/* Right Panel - Login Form */}
                <div className="login-right-panel">
                    <div className="login-form-container">
                        <h1 className="login-title">Welcome Back</h1>
                        <p className="login-subtitle">Sign in to your dashboard</p>

                        <form onSubmit={handleSubmit} className="login-form">
                            <div className="form-group">
                                <input
                                    className="form-input"
                                    type="text"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    placeholder="Username"
                                    autoFocus
                                />
                            </div>
                            
                            <div className="form-group">
                                <div className="password-input-wrapper">
                                    <input
                                        className="form-input"
                                        type={showPassword ? 'text' : 'password'}
                                        value={password}
                                        onChange={(e) => setPassword(e.target.value)}
                                        placeholder="Enter your password"
                                    />
                                    <button 
                                        type="button" 
                                        className="password-toggle"
                                        onClick={() => setShowPassword(!showPassword)}
                                    >
                                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                                    </button>
                                </div>
                            </div>

                            {error && (
                                <div className="error-message">
                                    <AlertCircle size={16} />
                                    {error}
                                </div>
                            )}

                            <button type="submit" className="login-btn" disabled={loading}>
                                {loading ? 'Signing in...' : 'Sign In'}
                            </button>

                            <div className="login-footer">
                                <p>Need help? Contact your system administrator</p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
