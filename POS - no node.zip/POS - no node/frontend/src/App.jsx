import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import ProtectedRoute from './components/ProtectedRoute';
import DashboardRedirect from './components/DashboardRedirect';
import AlertPopup from './components/AlertPopup';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import SystemDashboard from './pages/SystemDashboard';
import POS from './pages/POS';
import Items from './pages/Items';
import History from './pages/History';
import AdminManagement from './pages/AdminManagement';
import AlertsManagement from './pages/AlertsManagement';
import Settings from './pages/Settings';
import InvoiceView from './pages/InvoiceView';
import './index.css';

// Keyboard shortcuts handler component
const KeyboardShortcuts = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const isSysAdmin = user?.role === 'sysadmin';

  React.useEffect(() => {
    const handleKeyboardShortcuts = (e) => {
      // Don't trigger shortcuts when typing in inputs
      const activeElement = document.activeElement;
      const isTyping = activeElement.tagName === 'INPUT' || 
                       activeElement.tagName === 'TEXTAREA' || 
                       activeElement.isContentEditable;

      // Allow Escape key even when typing (to blur inputs)
      if (e.key === 'Escape' && isTyping) {
        activeElement.blur();
        return;
      }

      // Alt + Enter for fullscreen - works everywhere, even when typing
      if (e.altKey && e.key === 'Enter') {
        e.preventDefault();
        if (!document.fullscreenElement) {
          document.documentElement.requestFullscreen().catch(err => {
            console.error('Error attempting to enable fullscreen:', err);
          });
        } else {
          document.exitFullscreen().catch(err => {
            console.error('Error attempting to exit fullscreen:', err);
          });
        }
        return;
      }

      if (isTyping) return;

      // Don't trigger on login page
      if (location.pathname === '/login') return;

      // Alt + key shortcuts for navigation
      if (e.altKey) {
        switch (e.key.toLowerCase()) {
          case 'd':
            e.preventDefault();
            navigate(isSysAdmin ? '/system' : '/dashboard');
            break;
          case 'b':
            e.preventDefault();
            if (!isSysAdmin) navigate('/pos');
            break;
          case 'h':
            e.preventDefault();
            if (!isSysAdmin) navigate('/history');
            break;
          case 'i':
            e.preventDefault();
            if (!isSysAdmin) navigate('/items');
            break;
          case 's':
            e.preventDefault();
            if (!isSysAdmin) navigate('/settings');
            break;
          case 'a':
            e.preventDefault();
            if (isSysAdmin) navigate('/admin');
            break;
          case 'l':
            e.preventDefault();
            if (isSysAdmin) navigate('/alerts');
            break;
          case 'q':
            e.preventDefault();
            logout();
            break;
          default:
            break;
        }
      }

      // Ctrl + key shortcuts for actions
      if (e.ctrlKey && !e.shiftKey && !e.altKey) {
        switch (e.key.toLowerCase()) {
          case '/':
            e.preventDefault();
            // Focus search input if exists
            const searchInput = document.querySelector('input[type="text"][placeholder*="Search"], input[type="search"]');
            if (searchInput) searchInput.focus();
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyboardShortcuts);
    return () => window.removeEventListener('keydown', handleKeyboardShortcuts);
  }, [navigate, location, user, isSysAdmin, logout]);

  return null;
};

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <CartProvider>
          <KeyboardShortcuts />
          <AlertPopup />
          <Routes>
            <Route path="/login" element={<Login />} />
            
            {/* Public invoice view - no authentication required */}
            <Route path="/invoice/:invoiceId" element={<InvoiceView />} />

            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<DashboardRedirect />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/system" element={<SystemDashboard />} />
              <Route path="/pos" element={<POS />} />
              <Route path="/items" element={<Items />} />
              <Route path="/history" element={<History />} />
              <Route path="/admin" element={<AdminManagement />} />
              <Route path="/alerts" element={<AlertsManagement />} />
              <Route path="/settings" element={<Settings />} />
            </Route>

            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
