import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, Send, Sparkles, Loader, X, ChevronDown, HelpCircle, TrendingUp, BarChart3, Package, DollarSign, Bot } from 'lucide-react';
import api from '../api';

const AIAssistant = () => {
    const [greeting, setGreeting] = useState('');
    const [messages, setMessages] = useState([]);
    const [inputMessage, setInputMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [aiAvailable, setAiAvailable] = useState(true);
    const [showExamples, setShowExamples] = useState(false);
    const [examples, setExamples] = useState([]);
    const [isTyping, setIsTyping] = useState(false);
    const [isChatOpen, setIsChatOpen] = useState(false);
    const [isHovered, setIsHovered] = useState(false);
    const messagesEndRef = useRef(null);
    const messagesContainerRef = useRef(null);

    useEffect(() => {
        fetchGreeting();
        fetchExamples();
        checkAIStatus();
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const scrollToBottom = () => {
        if (messagesContainerRef.current) {
            messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
        }
    };

    const fetchGreeting = async () => {
        try {
            const response = await api.get('/ai/greeting');
            setGreeting(response.data.greeting);
            setAiAvailable(response.data.ai_available);
        } catch (error) {
            console.error('Error fetching greeting:', error);
            setGreeting('Hello! How can I help you today? 👋');
        }
    };

    const fetchExamples = async () => {
        try {
            const response = await api.get('/ai/examples');
            setExamples(response.data.examples);
        } catch (error) {
            console.error('Error fetching examples:', error);
        }
    };

    const checkAIStatus = async () => {
        try {
            const response = await api.get('/ai/status');
            setAiAvailable(response.data.available && response.data.initialized);
        } catch (error) {
            console.error('Error checking AI status:', error);
            setAiAvailable(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!inputMessage.trim() || isLoading) return;

        const userMessage = inputMessage.trim();
        setInputMessage('');

        setMessages(prev => [...prev, { type: 'user', content: userMessage, timestamp: new Date() }]);
        setIsLoading(true);
        setIsTyping(true);

        try {
            const response = await api.post('/ai/query', {
                message: userMessage,
                show_details: false
            });

            setTimeout(() => {
                setIsTyping(false);
                setMessages(prev => [...prev, {
                    type: 'ai',
                    content: response.data.response,
                    intent: response.data.intent,
                    confidence: response.data.confidence,
                    timestamp: new Date()
                }]);
            }, 300);
        } catch (error) {
            console.error('Error querying AI:', error);
            setIsTyping(false);
            const errorMessage = error.response?.data?.detail || 'Sorry, I encountered an error. Please try again.';
            setMessages(prev => [...prev, {
                type: 'ai',
                content: errorMessage,
                isError: true,
                timestamp: new Date()
            }]);
        } finally {
            setIsLoading(false);
        }
    };

    const handleExampleClick = (example) => {
        setInputMessage(example);
        setShowExamples(false);
    };

    const clearChat = () => {
        setMessages([]);
    };

    const toggleChat = () => {
        setIsChatOpen(!isChatOpen);
    };

    return (
        <>
            {/* Chat Button */}
            <button
                onClick={toggleChat}
                className={"btn flex items-center gap-2"}
                style={{ 
                    backgroundColor: '#5046e5',
                    color: 'white',
                    textTransform: 'uppercase', 
                    letterSpacing: '2.5px',
                    border: 'none',
                    margin: '0 10px'
                }}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#4037d8'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#5046e5'}
            >
                <MessageCircle size={20} style={{ color: 'white' }} />
                <span className="text-sm whitespace-nowrap">
                    Chat with AI
                </span>
            </button>

            {/* Chat Window */}
            {isChatOpen && (
                <div 
                    className="fixed shadow-lg text-white" 
                    style={{ 
                        top: '80px',
                        right: '20px',
                        width: '450px', 
                        maxWidth: 'calc(100vw - 40px)', 
                        height: '580px', 
                        maxHeight: 'calc(100vh - 120px)',
                        zIndex: 99999,
                        background: 'white'
                    }}
                >
                    <div className="h-full overflow-hidden shadow-lg border border-gray-200 bg-white flex flex-col" style={{ borderRadius: 0 }}>
            {/* Header */}
            <div className="btn flex items-center gap-2">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-white/20 rounded-lg">
                        <Sparkles size={20} className="text-white" />
                    </div>
                    <div>
                        <h2 className="text-base font-semibold text-white m-0">AI Assistant</h2>
                        <p className="text-xs text-indigo-100 m-0">Ask me anything about your business</p>
                    </div>
                </div>
                <button
                    onClick={toggleChat}
                    className="text-black "
                >
                    <X size={30} className="text-black" />
                </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-hidden flex flex-col p-4 bg-gray-50">
                {/* Greeting */}
                <div className="mb-4 p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
                    <div className="flex items-start gap-3">
                        <div className="p-2 bg-indigo-100 rounded-lg">
                            <Bot size={18} className="text-indigo-600" />
                        </div>
                        <p className="text-sm text-gray-700 m-0 leading-relaxed">{greeting}</p>
                    </div>
                </div>

                {/* Messages */}
                {messages.length > 0 && (
                    <div className="flex-1 flex flex-col mb-4 overflow-hidden">
                        <div className="flex justify-between items-center mb-3 flex-shrink-0">
                            <h3 className="text-xs font-semibold text-gray-600 uppercase m-0">Conversation</h3>
                            <button
                                onClick={clearChat}
                                className="text-xs text-red-600 hover:bg-red-50 px-3 py-1 rounded-lg flex items-center gap-1 transition-all"
                            >
                                <X size={12} />
                                Clear
                            </button>
                        </div>
                        <div ref={messagesContainerRef} className="flex-1 space-y-3 overflow-y-auto p-3 bg-white rounded-lg border border-gray-200 custom-scrollbar">
                            {messages.map((msg, index) => (
                                <div
                                    key={index}
                                    className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div
                                        className={`max-w-[80%] ${
                                            msg.type === 'user'
                                                ? 'bg-indigo-600 text-white rounded-lg rounded-tr-none'
                                                : msg.isError
                                                ? 'bg-red-50 text-red-800 border border-red-200 rounded-lg rounded-tl-none'
                                                : 'bg-gray-100 text-gray-800 rounded-lg rounded-tl-none'
                                        } p-3`}
                                    >
                                        {msg.type === 'ai' && !msg.isError && (
                                            <div className="flex items-center gap-2 mb-2 pb-2 border-b border-gray-200">
                                                <Bot size={14} className="text-indigo-600" />
                                                <span className="text-xs font-semibold text-gray-600">AI</span>
                                            </div>
                                        )}
                                        <p className="text-sm m-0 whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                                        {msg.timestamp && (
                                            <p className="text-xs opacity-60 mt-2 m-0">
                                                {new Date(msg.timestamp).toLocaleTimeString('en-US', { 
                                                    hour: '2-digit', 
                                                    minute: '2-digit' 
                                                })}
                                            </p>
                                        )}
                                    </div>
                                </div>
                            ))}
                            {isTyping && (
                                <div className="flex justify-start">
                                    <div className="bg-gray-100 rounded-lg rounded-tl-none p-3">
                                        <div className="flex items-center gap-2">
                                            <div className="flex gap-1">
                                                <span className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce"></span>
                                                <span className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></span>
                                                <span className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></span>
                                            </div>
                                            <span className="text-xs text-gray-600">Typing...</span>
                                        </div>
                                    </div>
                                </div>
                            )}
                            <div ref={messagesEndRef} />
                        </div>
                    </div>
                )}

                {/* Example Questions */}
                {messages.length === 0 && (
                    <div className="flex-1 overflow-y-auto mb-4">
                        <button
                            onClick={() => setShowExamples(!showExamples)}
                            className="flex items-center gap-2 text-sm text-indigo-600 hover:bg-indigo-50 px-3 py-2 rounded-lg transition-all mb-3 font-medium"
                        >
                            <HelpCircle size={16} />
                            {showExamples ? 'Hide' : 'Show'} Example Questions
                        </button>
                        {showExamples && examples.length > 0 && (
                            <div className="space-y-2">
                                {examples.slice(0, 4).map((example, index) => (
                                    <button
                                        key={index}
                                        onClick={() => handleExampleClick(example)}
                                        className="w-full text-left text-sm p-3 bg-white hover:bg-indigo-50 rounded-lg border border-gray-200 hover:border-indigo-300 transition-all"
                                    >
                                        <span className="text-gray-700">{example}</span>
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>
                )}

                {/* Input */}
                {aiAvailable ? (
                    <form onSubmit={handleSubmit} className="flex-shrink-0">
                        <div 
                            className="flex items-center gap-2"
                            style={{
                                background: '#f8f9fb',
                                borderRadius: '12px',
                                padding: '8px 8px 8px 16px',
                            }}
                        >
                            {/* Input Field */}
                            <input
                                type="text"
                                value={inputMessage}
                                onChange={(e) => setInputMessage(e.target.value)}
                                placeholder="Ask me anything..."
                                disabled={isLoading}
                                className="flex-1 bg-transparent focus:outline-none disabled:opacity-50"
                                style={{ 
                                    minWidth: 0,
                                    fontSize: '14px',
                                    color: '#374151',
                                    padding: '8px 0',
                                    border: 'none'
                                }}
                            />
                            
                            {/* Send Button */}
                            <button
                                type="submit"
                                disabled={isLoading || !inputMessage.trim()}
                                style={{
                                    width: '40px',
                                    height: '40px',
                                    borderRadius: '10px',
                                    background: isLoading || !inputMessage.trim() 
                                        ? '#e5e7eb' 
                                        : '#5046e5',
                                    border: 'none',
                                    cursor: isLoading || !inputMessage.trim() ? 'not-allowed' : 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    transition: 'all 0.2s ease',
                                    flexShrink: 0
                                }}
                                onMouseEnter={(e) => {
                                    if (!isLoading && inputMessage.trim()) {
                                        e.currentTarget.style.background = '#4338ca';
                                    }
                                }}
                                onMouseLeave={(e) => {
                                    if (!isLoading && inputMessage.trim()) {
                                        e.currentTarget.style.background = '#5046e5';
                                    }
                                }}
                            >
                                {isLoading ? (
                                    <Loader size={18} color="#9ca3af" className="animate-spin" />
                                ) : (
                                    <Send 
                                        size={18} 
                                        color={inputMessage.trim() ? 'white' : '#9ca3af'}
                                    />
                                )}
                            </button>
                        </div>
                        
                        {/* Quick suggestions - only show when no messages */}
                        {messages.length === 0 && (
                            <div className="flex items-center gap-1 mt-3 flex-wrap">
                                {['📊 Today\'s sales', '🏆 Top items', '📈 Summary'].map((hint, i) => (
                                    <button
                                        key={i}
                                        type="button"
                                        onClick={() => setInputMessage(hint.replace(/^[^\s]+\s/, ''))}
                                        style={{
                                            fontSize: '12px',
                                            padding: '6px 12px',
                                            borderRadius: '20px',
                                            background: 'white',
                                            color: '#6b7280',
                                            border: '1px solid #e5e7eb',
                                            cursor: 'pointer',
                                            transition: 'all 0.2s ease',
                                            whiteSpace: 'nowrap'
                                        }}
                                        onMouseEnter={(e) => {
                                            e.currentTarget.style.borderColor = '#5046e5';
                                            e.currentTarget.style.color = '#5046e5';
                                            e.currentTarget.style.background = '#f5f3ff';
                                        }}
                                        onMouseLeave={(e) => {
                                            e.currentTarget.style.borderColor = '#e5e7eb';
                                            e.currentTarget.style.color = '#6b7280';
                                            e.currentTarget.style.background = 'white';
                                        }}
                                    >
                                        {hint}
                                    </button>
                                ))}
                            </div>
                        )}
                    </form>
                    ) : (
                        <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                            <p className="text-sm text-amber-800 m-0">
                                ⚠️ AI service is currently unavailable
                            </p>
                        </div>
                    )}
                </div>
            </div>
                </div>
            )}
        </>
    );
};

export default AIAssistant;
