from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

# --- User Schemas ---
class UserBase(BaseModel):
    username: str
    role: str = "admin" # Default changed to admin as cashier is removed
    business_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    full_name: Optional[str] = None
    business_address: Optional[str] = None
    business_type: Optional[str] = None
    tax_id: Optional[str] = None
    tax_rate: Optional[float] = 0.0
    # GST & Business Registration
    gstin: Optional[str] = None
    fssai_license: Optional[str] = None
    pan_number: Optional[str] = None
    # Invoice/Store Details
    store_email: Optional[str] = None
    store_phone: Optional[str] = None
    bank_account: Optional[str] = None
    bank_name: Optional[str] = None
    account_name: Optional[str] = None
    invoice_notes: Optional[str] = None
    invoice_terms: Optional[str] = None
    whatsapp_message: Optional[str] = None
    monthly_target: Optional[float] = None  # Monthly revenue target for dashboard
    active_window_start: Optional[str] = None  # Login access start date (YYYY-MM-DD)
    active_window_end: Optional[str] = None  # Login access end date (YYYY-MM-DD)

class UserCreate(UserBase):
    password: str
    subscription_status: str = "active"

class PasswordVerification(BaseModel):
    password: str

class UserUpdateProfile(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None # New password
    current_password: Optional[str] = None
    business_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    full_name: Optional[str] = None
    business_address: Optional[str] = None
    business_type: Optional[str] = None
    tax_id: Optional[str] = None
    tax_rate: Optional[float] = None
    # GST & Business Registration
    gstin: Optional[str] = None
    fssai_license: Optional[str] = None
    pan_number: Optional[str] = None
    # Invoice/Store Details
    store_email: Optional[str] = None
    store_phone: Optional[str] = None
    bank_account: Optional[str] = None
    bank_name: Optional[str] = None
    account_name: Optional[str] = None
    invoice_notes: Optional[str] = None
    invoice_terms: Optional[str] = None
    whatsapp_message: Optional[str] = None
    monthly_target: Optional[float] = None  # Monthly revenue target for dashboard
    active_window_start: Optional[str] = None  # Login access start date (YYYY-MM-DD)
    active_window_end: Optional[str] = None  # Login access end date (YYYY-MM-DD)

class UserLogin(BaseModel):
    username: str
    password: str

class UserResponse(UserBase):
    id: str  # MongoDB ObjectId as string
    is_active: bool
    subscription_status: str = "active"
    active_window_start: Optional[str] = None  # Login access start date
    active_window_end: Optional[str] = None  # Login access end date
    created_at: Optional[datetime] = None
    last_login: Optional[datetime] = None
    class Config:
        from_attributes = True

# --- Item Schemas ---
class ItemBase(BaseModel):
    name: str
    category: str
    price: float
    tax_rate: float = 0.0
    hsn_code: Optional[str] = None  # HSN/SAC code for GST
    stock_quantity: int = 0
    limit_stock: bool = True

class ItemCreate(ItemBase):
    pass

class ItemUpdate(ItemBase):
    pass

class ItemResponse(ItemBase):
    id: str  # MongoDB ObjectId as string
    admin_id: str  # MongoDB ObjectId as string
    class Config:
        from_attributes = True

# --- Invoice Schemas ---
class InvoiceItemCreate(BaseModel):
    item_id: Optional[str] = None  # MongoDB ObjectId as string
    item_name: str
    quantity: int
    unit_price: float
    tax_amount: float

class InvoiceCreate(BaseModel):
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_address: Optional[str] = None
    customer_gstin: Optional[str] = None
    payment_mode: str = "Cash"
    transaction_id: Optional[str] = None
    payment_status: str = "Paid"
    table_number: Optional[str] = None
    table_name: Optional[str] = None
    created_at: Optional[datetime] = None  # Allow frontend to send device timestamp
    items: List[InvoiceItemCreate]

class InvoiceItemResponse(BaseModel):
    """Matches stored invoice item subdocuments (item_id, not id)."""
    item_id: Optional[str] = None
    item_name: str
    quantity: int
    unit_price: float
    tax_amount: float
    total_price: float

    class Config:
        from_attributes = True

class InvoiceResponse(BaseModel):
    id: str  # MongoDB ObjectId as string
    admin_id: str  # MongoDB ObjectId as string
    invoice_number: str
    created_at: datetime
    customer_name: Optional[str]
    customer_phone: Optional[str]
    customer_address: Optional[str] = None
    customer_gstin: Optional[str] = None
    total_amount: float
    payment_mode: str
    transaction_id: Optional[str] = None
    payment_status: str = "Paid"
    table_number: Optional[str] = None
    table_name: Optional[str] = None
    # Business details
    business_name: Optional[str] = None
    business_address: Optional[str] = None
    store_email: Optional[str] = None
    store_phone: Optional[str] = None
    gstin: Optional[str] = None
    fssai_license: Optional[str] = None
    pan_number: Optional[str] = None
    bank_account: Optional[str] = None
    bank_name: Optional[str] = None
    account_name: Optional[str] = None
    invoice_notes: Optional[str] = None
    invoice_terms: Optional[str] = None
    items: List[InvoiceItemResponse]
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

# --- System Settings Schemas ---
class SystemPasswordChange(BaseModel):
    current_password: str
    new_password: str

# --- Table Schemas ---
class TableBase(BaseModel):
    table_number: str
    table_name: Optional[str] = None
    capacity: int = 4
    is_active: bool = True

class TableCreate(TableBase):
    pass

class TableUpdate(BaseModel):
    table_number: Optional[str] = None
    table_name: Optional[str] = None
    capacity: Optional[int] = None
    is_active: Optional[bool] = None

class TableResponse(TableBase):
    id: str
    admin_id: str
    created_at: datetime
    updated_at: datetime
    class Config:
        from_attributes = True

