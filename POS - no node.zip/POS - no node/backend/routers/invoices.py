from fastapi import APIRouter, Depends, HTTPException
from typing import List
from datetime import datetime, timezone, timedelta
from pymongo.database import Database
from bson import ObjectId
from .. import schemas, database, auth
from ..models import InvoiceDocument, InvoiceItemDocument, serialize_doc, serialize_docs

# India Standard Time (IST) - GMT+5:30
IST = timezone(timedelta(hours=5, minutes=30))

router = APIRouter(
    prefix="/invoices",
    tags=["invoices"],
)

@router.get("/", response_model=List[schemas.InvoiceResponse])
def read_invoices(
    skip: int = 0, 
    limit: int = 100, 
    db: Database = Depends(database.get_db), 
    current_user: dict = Depends(auth.get_current_active_user)
):
    """Get invoices - filtered by admin_id for multi-tenant isolation"""
    if current_user.get("role") == 'sysadmin':
        # SysAdmin can see all invoices
        invoices = list(database.invoices_collection.find({}).sort("created_at", -1).skip(skip).limit(limit))
    else:
        # Admin sees only their own invoices
        invoices = list(database.invoices_collection.find(
            {"admin_id": current_user["id"]}
        ).sort("created_at", -1).skip(skip).limit(limit))
    
    # Enrich invoices with admin store details
    result = []
    for invoice in invoices:
        invoice_dict = serialize_doc(invoice)
        # Get admin details
        admin = database.users_collection.find_one({"_id": ObjectId(invoice["admin_id"])})
        if admin:
            invoice_dict['business_name'] = admin.get('business_name')
            invoice_dict['business_address'] = admin.get('business_address')
            invoice_dict['store_email'] = admin.get('store_email')
            invoice_dict['store_phone'] = admin.get('store_phone')
            invoice_dict['gstin'] = admin.get('gstin')
            invoice_dict['fssai_license'] = admin.get('fssai_license')
            invoice_dict['pan_number'] = admin.get('pan_number')
            invoice_dict['bank_account'] = admin.get('bank_account')
            invoice_dict['bank_name'] = admin.get('bank_name')
            invoice_dict['account_name'] = admin.get('account_name')
            invoice_dict['invoice_notes'] = admin.get('invoice_notes')
            invoice_dict['invoice_terms'] = admin.get('invoice_terms')
        result.append(invoice_dict)
    
    return result

@router.post("/", response_model=schemas.InvoiceResponse)
def create_invoice(
    invoice: schemas.InvoiceCreate, 
    db: Database = Depends(database.get_db), 
    current_user: dict = Depends(auth.get_current_active_user)
):
    """Create invoice - auto-assign admin_id"""
    if current_user.get("role") == 'sysadmin':
        raise HTTPException(
            status_code=403, 
            detail="SysAdmin cannot create invoices. Please login as an admin user to use RECO POS."
        )
    
    if current_user.get("role") != 'admin':
        raise HTTPException(
            status_code=403,
            detail="Only admin users can create invoices"
        )
    
    # Generate Sequential Invoice Number per Admin
    admin_id = current_user["id"]
    counter_key = f"invoice_counter_{admin_id}"
    
    # Get or create counter for this admin
    counter_doc = database.system_settings_collection.find_one({"setting_key": counter_key})
    
    if counter_doc:
        next_number = counter_doc["value"] + 1
        database.system_settings_collection.update_one(
            {"setting_key": counter_key},
            {"$set": {"value": next_number}}
        )
    else:
        next_number = 1
        database.system_settings_collection.insert_one({
            "setting_key": counter_key,
            "value": next_number,
            "admin_id": admin_id,
            "created_at": datetime.now(IST)
        })
    
    # Format invoice number: INV-00001 (admin-specific)
    inv_number = f"INV-{str(next_number).zfill(5)}"
    
    total_amount = 0.0
    invoice_items = []
    
    for item in invoice.items:
        # Check stock - only for items belonging to this admin
        if item.item_id:
            db_item = database.items_collection.find_one({
                "_id": ObjectId(item.item_id),
                "admin_id": current_user["id"]  # Security: only admin's items
            })
            
            if not db_item:
                raise HTTPException(status_code=404, detail=f"Item {item.item_id} not found or access denied")
            
            if db_item.get("limit_stock"):
                if db_item.get("stock_quantity", 0) < item.quantity:
                    raise HTTPException(status_code=400, detail=f"Not enough stock for {db_item['name']}")
                # Update stock
                database.items_collection.update_one(
                    {"_id": ObjectId(item.item_id)},
                    {"$inc": {"stock_quantity": -item.quantity}}
                )
        
        # Calculate row total
        row_total = (item.unit_price * item.quantity) + item.tax_amount
        total_amount += row_total
        
        # Create invoice item document
        invoice_item = InvoiceItemDocument.create(
            item_id=item.item_id,
            item_name=item.item_name,
            quantity=item.quantity,
            unit_price=item.unit_price,
            tax_amount=item.tax_amount,
            total_price=row_total
        )
        invoice_items.append(invoice_item)
    
    # Create invoice with embedded items
    # Use the device timestamp directly - Pydantic converts ISO string to datetime automatically
    # The datetime from frontend is in UTC, so we don't apply any timezone conversion
    # This preserves the actual time the order was created on the device
    invoice_time = invoice.created_at if invoice.created_at else datetime.now(IST)
    
    new_invoice = InvoiceDocument.create(
        admin_id=current_user["id"],
        invoice_number=inv_number,
        customer_name=invoice.customer_name,
        customer_phone=invoice.customer_phone,
        customer_address=invoice.customer_address,
        customer_gstin=invoice.customer_gstin,
        total_amount=total_amount,
        payment_mode=invoice.payment_mode,
        transaction_id=invoice.transaction_id,
        payment_status=invoice.payment_status,
        items=invoice_items,
        created_at=invoice_time
    )
    
    # Add table information if provided
    if invoice.table_number:
        new_invoice['table_number'] = invoice.table_number
    if invoice.table_name:
        new_invoice['table_name'] = invoice.table_name
    
    result = database.invoices_collection.insert_one(new_invoice)
    new_invoice["_id"] = result.inserted_id
    
    # Enrich response with admin store details
    invoice_dict = serialize_doc(new_invoice)
    invoice_dict['business_name'] = current_user.get('business_name')
    invoice_dict['business_address'] = current_user.get('business_address')
    invoice_dict['store_email'] = current_user.get('store_email')
    invoice_dict['store_phone'] = current_user.get('store_phone')
    invoice_dict['gstin'] = current_user.get('gstin')
    invoice_dict['fssai_license'] = current_user.get('fssai_license')
    invoice_dict['pan_number'] = current_user.get('pan_number')
    invoice_dict['bank_account'] = current_user.get('bank_account')
    invoice_dict['bank_name'] = current_user.get('bank_name')
    invoice_dict['account_name'] = current_user.get('account_name')
    invoice_dict['invoice_notes'] = current_user.get('invoice_notes')
    invoice_dict['invoice_terms'] = current_user.get('invoice_terms')
    
    return invoice_dict

